import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.a9ff9ae813514f4380dca2a2cba1cfc7',
  appName: 'stroom-check-app',
  webDir: 'dist',
  server: {
    url: 'https://a9ff9ae8-1351-4f43-80dc-a2a2cba1cfc7.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#ffffff',
      showSpinner: false
    }
  }
};

export default config;