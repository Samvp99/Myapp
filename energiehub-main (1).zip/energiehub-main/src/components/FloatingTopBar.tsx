import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Home, 
  BarChart3, 
  FileText, 
  Settings, 
  User, 
  Bell,
  LogOut,
  ChevronDown,
  Clock,
  Edit,
  HelpCircle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/components/ui/sonner';
import { useUserRole } from '@/hooks/useUserRole';

interface FloatingTopBarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const FloatingTopBar: React.FC<FloatingTopBarProps> = ({ activeTab, setActiveTab }) => {
  const navigate = useNavigate();
  const { isAdmin } = useUserRole();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [showBolts, setShowBolts] = useState(false);

  const triggerLightning = () => {
    setShowBolts(false);
    requestAnimationFrame(() => setShowBolts(true));
    setTimeout(() => setShowBolts(false), 1100);
  };

  const handleHover = () => {
    setShowBolts(true);
    setTimeout(() => setShowBolts(false), 800);
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsAuthenticated(!!session);
      setUserEmail(session?.user?.email ?? null);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsAuthenticated(!!session);
      setUserEmail(session?.user?.email ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    toast("Uitgelogd", { description: "Je bent succesvol uitgelogd." });
    navigate("/");
  };

  const userInitials = userEmail ? userEmail[0]?.toUpperCase() : 'G';

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'prices', label: 'Kwartierprijzen', icon: Clock },
    { id: 'usage', label: 'Verbruik', icon: BarChart3 },
    { id: 'invoices', label: 'Facturen', icon: FileText },
    { id: 'profile', label: 'Profiel', icon: User },
    { id: 'changes', label: 'Wijzigingen', icon: Edit },
    { id: 'faq', label: 'FAQ', icon: HelpCircle },
  ];

  return (
    <TooltipProvider>
      {/* Desktop Navigation */}
      <div className="hidden md:block fixed top-6 left-1/2 -translate-x-1/2 z-50 animate-enter">
        <div className="inline-flex items-center gap-3 backdrop-blur-lg bg-white/80 dark:bg-gray-900/80 border border-white/30 dark:border-gray-700/30 rounded-full px-4 py-1.5 shadow-2xl shadow-black/10 ring-1 ring-black/5">
          {/* Navigation Menu */}
          <div className="flex items-center gap-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <Tooltip key={item.id}>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setActiveTab(item.id)}
                      className={`rounded-full p-2.5 transition-all duration-300 ${
                        activeTab === item.id 
                          ? 'bg-primary text-primary-foreground shadow-lg scale-105 hover:bg-primary/90' 
                          : 'hover:bg-accent hover:text-accent-foreground hover-scale'
                      }`}
                    >
                      <Icon className="h-4 w-4" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent 
                    side="bottom" 
                    className="bg-popover/95 backdrop-blur-md border border-border/50 text-xs font-medium"
                  >
                    {item.label}
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>

          {/* Auth controls */}
          <div className="flex items-center">
            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="rounded-full flex items-center gap-2 hover:bg-accent p-2">
                    <Avatar className="h-7 w-7">
                      <AvatarImage src="/placeholder-avatar.jpg" alt={userEmail ?? 'Gebruiker'} />
                      <AvatarFallback className="bg-primary text-primary-foreground text-xs font-medium">
                        {userInitials}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronDown className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56 bg-popover/95 backdrop-blur-lg border border-border/50 rounded-xl shadow-xl">
                  <DropdownMenuItem className="flex items-center gap-2 rounded-lg">
                    <User className="h-4 w-4" />
                    <span className="font-normal">Profiel</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center gap-2 rounded-lg">
                    <Bell className="h-4 w-4" />
                    <span className="font-normal">Notificaties</span>
                    <Badge variant="secondary" className="ml-auto">3</Badge>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="flex items-center gap-2 rounded-lg">
                    <Settings className="h-4 w-4" />
                    <span className="font-normal">Account instellingen</span>
                  </DropdownMenuItem>
                  {isAdmin && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate('/admin')} className="flex items-center gap-2 rounded-lg font-medium">
                        <Settings className="h-4 w-4" />
                        <span>Admin Portaal</span>
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-destructive rounded-lg">
                    <LogOut className="h-4 w-4" />
                    <span className="font-normal">Uitloggen</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="relative">
                <Button
                  onMouseEnter={handleHover}
                  onClick={() => { triggerLightning(); navigate('/auth'); }}
                  className="rounded-full px-4 py-2 hover-scale relative z-10"
                >
                  Inloggen
                </Button>
                {showBolts && (
                  <div className="pointer-events-none absolute inset-0 overflow-visible">
                    <span className="absolute -top-1 -left-1 select-none" style={{ animation: 'bolt-pop-tl 1.1s ease-out forwards', animationDelay: '0ms' }}>⚡</span>
                    <span className="absolute -top-1 -right-1 select-none" style={{ animation: 'bolt-pop-tr 1.1s ease-out forwards', animationDelay: '60ms' }}>⚡</span>
                    <span className="absolute -bottom-1 -left-1 select-none" style={{ animation: 'bolt-pop-bl 1.1s ease-out forwards', animationDelay: '120ms' }}>⚡</span>
                    <span className="absolute -bottom-1 -right-1 select-none" style={{ animation: 'bolt-pop-br 1.1s ease-out forwards', animationDelay: '180ms' }}>⚡</span>
                    <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 select-none" style={{ animation: 'bolt-pop-center 1.1s ease-out forwards', animationDelay: '90ms' }}>⚡</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-lg border-t border-border/50 shadow-lg">
        <div className="flex items-center justify-around px-2 py-2 safe-area-inset-bottom">
          {menuItems.slice(0, 5).map((item) => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant="ghost"
                size="sm"
                onClick={() => setActiveTab(item.id)}
                className={`flex-col h-auto py-2 px-3 gap-1 ${
                  activeTab === item.id 
                    ? 'text-primary bg-primary/10' 
                    : 'text-muted-foreground'
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
              </Button>
            );
          })}
          
          {/* User Menu on Mobile */}
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex-col h-auto py-2 px-3 gap-1 text-muted-foreground">
                  <User className="h-5 w-5" />
                  <span className="text-[10px] font-medium">Meer</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="top" className="w-56 mb-2 bg-popover/95 backdrop-blur-lg border border-border/50 rounded-xl shadow-xl">
                <DropdownMenuItem onClick={() => setActiveTab('profile')} className="flex items-center gap-2 rounded-lg">
                  <User className="h-4 w-4" />
                  <span className="font-normal">Profiel</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveTab('changes')} className="flex items-center gap-2 rounded-lg">
                  <Edit className="h-4 w-4" />
                  <span className="font-normal">Wijzigingen</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setActiveTab('faq')} className="flex items-center gap-2 rounded-lg">
                  <HelpCircle className="h-4 w-4" />
                  <span className="font-normal">FAQ</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="flex items-center gap-2 rounded-lg">
                  <Bell className="h-4 w-4" />
                  <span className="font-normal">Notificaties</span>
                  <Badge variant="secondary" className="ml-auto">3</Badge>
                </DropdownMenuItem>
                {isAdmin && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/admin')} className="flex items-center gap-2 rounded-lg font-medium">
                      <Settings className="h-4 w-4" />
                      <span>Admin Portaal</span>
                    </DropdownMenuItem>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="flex items-center gap-2 text-destructive rounded-lg">
                  <LogOut className="h-4 w-4" />
                  <span className="font-normal">Uitloggen</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              onClick={() => { navigate('/auth'); }}
              size="sm"
              className="flex-col h-auto py-2 px-3 gap-1"
            >
              <User className="h-5 w-5" />
              <span className="text-[10px] font-medium">Login</span>
            </Button>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
};

export default FloatingTopBar;