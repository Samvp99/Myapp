import React, { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bot, Send, X, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const Sparky: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "greet-1",
      role: "assistant",
      content: "Hey 👋, ask me anything!",
      timestamp: new Date(),
    },
    {
      id: "persona",
      role: "assistant",
      content:
        "You are Sparky ⚡, a cheerful and helpful energy assistant. Be friendly, concise, and encouraging.",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  // Allow other components (e.g., FAQ) to open Sparky programmatically
  useEffect(() => {
    const handler: EventListener = () => setOpen(true);
    window.addEventListener('open-sparky', handler);
    return () => window.removeEventListener('open-sparky', handler);
  }, []);

  const handleToggle = () => {
    if (open) {
      setClosing(true);
      setTimeout(() => {
        setOpen(false);
        setClosing(false);
      }, 200);
    } else {
      setOpen(true);
    }
  };

  const send = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const context = messages.slice(-6).map((m) => ({ role: m.role, content: m.content }));
      const { data, error } = await supabase.functions.invoke("ai-chat", {
        body: {
          message: `Please respond as Sparky: ${userMessage.content}`,
          context,
        },
      });
      if (error) throw error;

      const ai: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data?.response || "⚡ I’m here to help!",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, ai]);
    } catch (e) {
      const ai: Message = {
        id: (Date.now() + 2).toString(),
        role: "assistant",
        content:
          "Oops, something went wrong. Please try again in a moment!",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, ai]);
    } finally {
      setLoading(false);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      send();
    }
  };

  if (!open) {
    return (
      <Button
        aria-label="Open Sparky assistant"
        onClick={handleToggle}
        className="fixed top-6 left-6 z-50 h-12 w-12 rounded-full bg-gradient-to-r from-energy-green to-energy-blue text-white shadow-2xl shadow-black/10 ring-1 ring-black/5 hover:scale-105 transition-transform"
        size="icon"
      >
        <Zap className="h-5 w-5" />
      </Button>
    );
  }

  return (
    <Card
      className={`fixed top-6 left-6 z-50 w-[92vw] sm:w-96 h-[70vh] sm:h-[28rem] flex flex-col origin-top-left backdrop-blur-lg bg-white/80 border border-white/30 ring-1 ring-black/5 shadow-2xl rounded-2xl ${
        closing ? "animate-exit" : "animate-enter"
      }`}
    >
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Zap className="h-5 w-5 text-energy-orange" />
          Sparky
        </CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleToggle}
          className="h-7 w-7"
          aria-label="Close Sparky"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col p-4 pt-0">
        <ScrollArea className="flex-1 pr-3">
          <div ref={scrollRef} className="h-full overflow-y-auto">
            <div className="space-y-3">
              {messages
                .filter((m) => m.id !== "persona")
                .map((m) => (
                  <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[85%] rounded-xl px-3 py-2 text-sm shadow ${
                        m.role === "user"
                          ? "bg-energy-blue text-white"
                          : "bg-white/70 border border-white/30 ring-1 ring-black/5 backdrop-blur-sm text-foreground"
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        {m.role === "assistant" ? (
                          <Bot className="h-4 w-4 mt-0.5 text-energy-orange" />
                        ) : null}
                        <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>
                      </div>
                    </div>
                  </div>
                ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white/70 border border-white/30 ring-1 ring-black/5 backdrop-blur-sm rounded-xl px-3 py-2 text-sm flex items-center gap-2">
                    <Bot className="h-4 w-4 text-energy-orange" />
                    <span className="text-muted-foreground">Sparky is typing…</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </ScrollArea>

        <div className="mt-3 flex items-center gap-2">
          <Input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Type your question…"
            disabled={loading}
            className="flex-1"
          />
          <Button onClick={send} disabled={loading || !input.trim()}>
            <Send className="h-4 w-4 mr-1" />
            Send
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default Sparky;
