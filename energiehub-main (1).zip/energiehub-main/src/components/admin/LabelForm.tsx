import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useLabels, Label } from '@/hooks/useLabels';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label as FormLabel } from '@/components/ui/label';
import { Card } from '@/components/ui/card';

interface LabelFormProps {
  labelId?: string;
  onSuccess: () => void;
  onCancel: () => void;
}

interface LabelFormData {
  name: string;
  slug: string;
  logo_url: string;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  contact_email: string;
  contact_phone: string;
  contact_address: string;
  website_url: string;
  electricity_tariff: string;
  gas_tariff: string;
}

export const LabelForm = ({ labelId, onSuccess, onCancel }: LabelFormProps) => {
  const { labels, createLabel, updateLabel } = useLabels();
  const { register, handleSubmit, reset, formState: { errors } } = useForm<LabelFormData>();

  const currentLabel = labelId ? labels?.find(l => l.id === labelId) : null;

  useEffect(() => {
    if (currentLabel) {
      reset({
        name: currentLabel.name,
        slug: currentLabel.slug,
        logo_url: currentLabel.logo_url || '',
        primary_color: currentLabel.primary_color,
        secondary_color: currentLabel.secondary_color,
        accent_color: currentLabel.accent_color,
        contact_email: currentLabel.contact_email || '',
        contact_phone: currentLabel.contact_phone || '',
        contact_address: currentLabel.contact_address || '',
        website_url: currentLabel.website_url || '',
        electricity_tariff: currentLabel.electricity_tariff?.toString() || '',
        gas_tariff: currentLabel.gas_tariff?.toString() || '',
      });
    }
  }, [currentLabel, reset]);

  const onSubmit = (data: LabelFormData) => {
    const labelData = {
      name: data.name,
      slug: data.slug,
      logo_url: data.logo_url || null,
      primary_color: data.primary_color,
      secondary_color: data.secondary_color,
      accent_color: data.accent_color,
      contact_email: data.contact_email || null,
      contact_phone: data.contact_phone || null,
      contact_address: data.contact_address || null,
      website_url: data.website_url || null,
      electricity_tariff: data.electricity_tariff ? parseFloat(data.electricity_tariff) : null,
      gas_tariff: data.gas_tariff ? parseFloat(data.gas_tariff) : null,
    };

    if (labelId) {
      updateLabel({ id: labelId, ...labelData });
    } else {
      createLabel(labelData as Omit<Label, 'id' | 'created_at' | 'updated_at'>);
    }
    onSuccess();
  };

  return (
    <Card className="p-6">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div className="grid grid-cols-2 gap-6">
          <div className="space-y-2">
            <FormLabel htmlFor="name">Label Naam *</FormLabel>
            <Input
              id="name"
              {...register('name', { required: 'Naam is verplicht' })}
              placeholder="Bijv. EnergieDirect"
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <FormLabel htmlFor="slug">Slug * (uniek)</FormLabel>
            <Input
              id="slug"
              {...register('slug', { required: 'Slug is verplicht' })}
              placeholder="energie-direct"
            />
            {errors.slug && (
              <p className="text-sm text-destructive">{errors.slug.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <FormLabel htmlFor="logo_url">Logo URL</FormLabel>
            <Input
              id="logo_url"
              {...register('logo_url')}
              placeholder="https://example.com/logo.png"
            />
          </div>

          <div className="space-y-2">
            <FormLabel htmlFor="website_url">Website URL</FormLabel>
            <Input
              id="website_url"
              {...register('website_url')}
              placeholder="https://example.com"
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Kleuren (HSL formaat)</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <FormLabel htmlFor="primary_color">Primaire Kleur *</FormLabel>
              <Input
                id="primary_color"
                {...register('primary_color', { required: true })}
                placeholder="hsl(142, 76%, 36%)"
              />
            </div>
            <div className="space-y-2">
              <FormLabel htmlFor="secondary_color">Secundaire Kleur *</FormLabel>
              <Input
                id="secondary_color"
                {...register('secondary_color', { required: true })}
                placeholder="hsl(142, 76%, 45%)"
              />
            </div>
            <div className="space-y-2">
              <FormLabel htmlFor="accent_color">Accent Kleur *</FormLabel>
              <Input
                id="accent_color"
                {...register('accent_color', { required: true })}
                placeholder="hsl(142, 76%, 30%)"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Contactgegevens</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <FormLabel htmlFor="contact_email">E-mail</FormLabel>
              <Input
                id="contact_email"
                type="email"
                {...register('contact_email')}
                placeholder="info@example.com"
              />
            </div>
            <div className="space-y-2">
              <FormLabel htmlFor="contact_phone">Telefoon</FormLabel>
              <Input
                id="contact_phone"
                {...register('contact_phone')}
                placeholder="+31 20 123 4567"
              />
            </div>
            <div className="space-y-2 col-span-2">
              <FormLabel htmlFor="contact_address">Adres</FormLabel>
              <Input
                id="contact_address"
                {...register('contact_address')}
                placeholder="Straatnaam 123, 1234 AB Amsterdam"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Tarieven</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <FormLabel htmlFor="electricity_tariff">Elektriciteit Tarief (€/kWh)</FormLabel>
              <Input
                id="electricity_tariff"
                type="number"
                step="0.00001"
                {...register('electricity_tariff')}
                placeholder="0.25"
              />
            </div>
            <div className="space-y-2">
              <FormLabel htmlFor="gas_tariff">Gas Tarief (€/m³)</FormLabel>
              <Input
                id="gas_tariff"
                type="number"
                step="0.00001"
                {...register('gas_tariff')}
                placeholder="0.85"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-4 justify-end">
          <Button type="button" variant="outline" onClick={onCancel}>
            Annuleren
          </Button>
          <Button type="submit">
            {labelId ? 'Bijwerken' : 'Aanmaken'}
          </Button>
        </div>
      </form>
    </Card>
  );
};
