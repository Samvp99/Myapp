import { Label } from '@/hooks/useLabels';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Edit, Globe, Mail, Phone } from 'lucide-react';

interface LabelsListProps {
  labels: Label[];
  onEdit: (id: string) => void;
}

export const LabelsList = ({ labels, onEdit }: LabelsListProps) => {
  if (labels.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">
          Nog geen labels aangemaakt. Klik op "Nieuw Label" om te beginnen.
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {labels.map((label) => (
        <Card key={label.id} className="relative">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="flex items-center gap-2">
                  {label.logo_url && (
                    <img 
                      src={label.logo_url} 
                      alt={label.name}
                      className="h-8 w-8 object-contain"
                    />
                  )}
                  {label.name}
                </CardTitle>
                <CardDescription>
                  <Badge variant="outline">{label.slug}</Badge>
                </CardDescription>
              </div>
              <Button 
                size="icon" 
                variant="ghost"
                onClick={() => onEdit(label.id)}
              >
                <Edit className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Kleuren</h4>
              <div className="flex gap-2">
                <div 
                  className="h-8 w-8 rounded border"
                  style={{ backgroundColor: label.primary_color.replace('hsl', '').replace('(', 'hsl(') }}
                  title="Primair"
                />
                <div 
                  className="h-8 w-8 rounded border"
                  style={{ backgroundColor: label.secondary_color.replace('hsl', '').replace('(', 'hsl(') }}
                  title="Secundair"
                />
                <div 
                  className="h-8 w-8 rounded border"
                  style={{ backgroundColor: label.accent_color.replace('hsl', '').replace('(', 'hsl(') }}
                  title="Accent"
                />
              </div>
            </div>

            <div className="space-y-2 text-sm">
              {label.contact_email && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="h-4 w-4" />
                  {label.contact_email}
                </div>
              )}
              {label.contact_phone && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  {label.contact_phone}
                </div>
              )}
              {label.website_url && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Globe className="h-4 w-4" />
                  <a 
                    href={label.website_url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="hover:underline"
                  >
                    Website
                  </a>
                </div>
              )}
            </div>

            {(label.electricity_tariff || label.gas_tariff) && (
              <div className="space-y-1 text-sm">
                <h4 className="font-semibold">Tarieven</h4>
                {label.electricity_tariff && (
                  <p className="text-muted-foreground">
                    Elektriciteit: €{label.electricity_tariff.toFixed(5)}/kWh
                  </p>
                )}
                {label.gas_tariff && (
                  <p className="text-muted-foreground">
                    Gas: €{label.gas_tariff.toFixed(5)}/m³
                  </p>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
