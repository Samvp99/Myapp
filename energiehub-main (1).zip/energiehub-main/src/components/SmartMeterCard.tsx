import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useSmartMeterData } from "@/hooks/useSmartMeterData";
import { 
  Zap, 
  Flame, 
  Wifi, 
  WifiOff, 
  Sun, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Plug
} from "lucide-react";

interface SmartMeterCardProps {
  contractId: string | null;
}

const SmartMeterCard = ({ contractId }: SmartMeterCardProps) => {
  const [isConnected, setIsConnected] = useState(false);
  const { 
    currentReading, 
    status, 
    loading, 
    error, 
    weeklyUsage, 
    weeklyLimit, 
    connectMeter, 
    disconnectMeter 
  } = useSmartMeterData(isConnected, contractId);

  const handleToggleConnection = () => {
    if (isConnected) {
      disconnectMeter();
      setIsConnected(false);
    } else {
      connectMeter();
      setIsConnected(true);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('nl-NL', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  if (!isConnected) {
    return (
      <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-muted/20 to-muted/5 border border-muted/30 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-muted-foreground" />
              <span>Live Verbruik</span>
            </div>
            <Badge variant="secondary" className="flex items-center space-x-1">
              <WifiOff className="w-3 h-3" />
              <span>Niet gekoppeld</span>
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="mb-4">
            <Plug className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
            <h3 className="text-lg font-semibold mb-2">Koppel je slimme meter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Zie je live energieverbruik en bespaar op je energierekening
            </p>
          </div>
          <Button onClick={handleToggleConnection} className="w-full">
            Slimme meter koppelen
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-primary animate-pulse" />
            <span>Verbinden met slimme meter...</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-destructive/10 to-destructive/5 border border-destructive/20 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <WifiOff className="w-5 h-5 text-destructive" />
              <span>Verbindingsfout</span>
            </div>
            <Button variant="outline" size="sm" onClick={handleToggleConnection}>
              Opnieuw proberen
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-destructive">{error}</p>
        </CardContent>
      </Card>
    );
  }

  const netPower = currentReading ? 
    currentReading.electricity.power_consumed - currentReading.electricity.power_produced : 0;
  
  const isProducing = netPower < 0;

  return (
    <div className="space-y-4">
      {/* Hoofdkaart met live data */}
      <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-energy-green/15 to-energy-blue/10 border border-white/20 shadow-lg shadow-energy-green/10">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-energy-green" />
              <span>Live Verbruik</span>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="default" className="flex items-center space-x-1 bg-energy-green/20 text-energy-green border-energy-green/30">
                <Wifi className="w-3 h-3" />
                <span>Verbonden</span>
              </Badge>
              <Button variant="ghost" size="sm" onClick={handleToggleConnection}>
                Loskoppelen
              </Button>
            </div>
          </CardTitle>
          {status.lastReading && (
            <p className="text-xs text-muted-foreground">
              Laatste update: {formatTime(status.lastReading)}
            </p>
          )}
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Elektriciteit */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-energy-blue" />
                <span className="text-sm font-medium">Elektriciteit</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs sm:text-sm text-muted-foreground">Verbruik</span>
                  <div className="flex items-center space-x-1">
                    <span className="text-base sm:text-lg font-bold text-energy-orange">
                      {currentReading?.electricity.power_consumed.toFixed(2)} kW
                    </span>
                    <TrendingUp className="w-3 h-3 sm:w-4 sm:h-4 text-energy-orange" />
                  </div>
                </div>
                {currentReading?.electricity.power_produced > 0 && (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground flex items-center space-x-1">
                      <Sun className="w-3 h-3" />
                      <span>Productie</span>
                    </span>
                    <div className="flex items-center space-x-1">
                      <span className="text-lg font-bold text-energy-green">
                        {currentReading.electricity.power_produced.toFixed(2)} kW
                      </span>
                      <TrendingDown className="w-3 h-3 text-energy-green" />
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between pt-1 border-t border-muted/20">
                  <span className="text-xs font-medium">Netto</span>
                  <div className="flex items-center space-x-1">
                    <span className={`text-lg font-bold ${isProducing ? 'text-energy-green' : 'text-energy-orange'}`}>
                      {Math.abs(netPower).toFixed(2)} kW
                    </span>
                    {isProducing ? (
                      <Badge variant="default" className="text-xs bg-energy-green/20 text-energy-green">
                        Terugleverend
                      </Badge>
                    ) : (
                      <Badge variant="default" className="text-xs bg-energy-orange/20 text-energy-orange">
                        Verbruikend
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Gas */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Flame className="w-4 h-4 text-energy-orange" />
                <span className="text-sm font-medium">Gas</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Stand</span>
                  <span className="text-lg font-bold text-foreground">
                    {currentReading?.gas.volume.toFixed(3)} m³
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Vandaag</span>
                  <span className="text-sm font-medium text-energy-orange">
                    +2.4 m³
                  </span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Meter info en wekelijks verbruik */}
      <Card className="backdrop-blur-lg bg-card/80 border border-muted/20">
        <CardContent className="pt-4">
          <div className="space-y-3">
            {/* Meter informatie */}
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center space-x-2">
                <span className="text-muted-foreground">Meter:</span>
                <span className="font-medium">{status.meterType}</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-muted-foreground">Signaal:</span>
                <div className="flex items-center space-x-1">
                  <div className={`w-2 h-2 rounded-full ${status.signalStrength > 70 ? 'bg-energy-green' : status.signalStrength > 40 ? 'bg-energy-orange' : 'bg-destructive'}`} />
                  <span className="font-medium">{status.signalStrength}%</span>
                </div>
              </div>
            </div>
            
            {/* Wekelijks verbruik */}
            <div className="pt-2 border-t border-muted/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Weekverbruik</span>
                <span className="text-xs text-muted-foreground">
                  {weeklyUsage.toFixed(0)} / {weeklyLimit} kWh
                </span>
              </div>
              <div className="w-full bg-muted/20 rounded-full h-2 mb-1">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${
                    weeklyUsage >= weeklyLimit ? 'bg-destructive' : 
                    weeklyUsage >= (weeklyLimit * 0.8) ? 'bg-energy-orange' : 
                    'bg-energy-green'
                  }`}
                  style={{ width: `${Math.min((weeklyUsage / weeklyLimit) * 100, 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>0 kWh</span>
                <span className={weeklyUsage >= weeklyLimit ? 'text-destructive font-medium' : weeklyUsage >= (weeklyLimit * 0.8) ? 'text-energy-orange font-medium' : ''}>
                  {Math.round((weeklyUsage / weeklyLimit) * 100)}%
                </span>
                <span>{weeklyLimit} kWh</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SmartMeterCard;