import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { 
  MessageCircle, 
  Phone, 
  Sparkles, 
  Bot, 
  Users,
  HelpCircle,
  Zap,
  Euro,
  FileText,
  Settings,
  Shield
} from 'lucide-react';

interface FAQProps {
  onOpenChatBot: () => void;
}

const FAQ: React.FC<FAQProps> = ({ onOpenChatBot }) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const faqCategories = [
    {
      id: 'billing',
      title: 'Facturen & Kosten',
      icon: Euro,
      color: 'bg-green-500/10 text-green-600',
      faqs: [
        {
          question: 'Waarom is mijn factuur hoger dan verwacht?',
          answer: 'Hogere facturen kunnen verschillende oorzaken hebben: verhoogd verbruik door weersomstandigheden, nieuwe apparaten, of gewijzigde tarieven. Bekijk je verbruiksoverzicht voor meer details.'
        },
        {
          question: 'Hoe kan ik mijn energiekosten verlagen?',
          answer: 'Tips om kosten te besparen: LED-verlichting gebruiken, thermostaat 1°C lager zetten, apparaten volledig uitschakelen, en energiezuinige apparaten kiezen.'
        },
        {
          question: 'Wat is het verschil tussen vaste en variabele tarieven?',
          answer: 'Vaste tarieven blijven gedurende je contract hetzelfde. Variabele tarieven kunnen maandelijks wijzigen op basis van marktprijzen.'
        }
      ]
    },
    {
      id: 'usage',
      title: 'Verbruik & Meterstanden',
      icon: Zap,
      color: 'bg-blue-500/10 text-blue-600',
      faqs: [
        {
          question: 'Hoe lees ik mijn slimme meter af?',
          answer: 'Druk op de knop van je slimme meter om door de verschillende standen te bladeren. Noteer de standen voor elektriciteit (dal en piek) en gas.'
        },
        {
          question: 'Waarom fluctueert mijn dagelijks verbruik?',
          answer: 'Verbruik varieert door weersomstandigheden, aantal mensen thuis, gebruik van verwarmingstoestellen, en verschillende dagelijkse activiteiten.'
        },
        {
          question: 'Wat is het verschil tussen piek- en daltarief?',
          answer: 'Piektarief geldt doordeweeks van 07:00-23:00, daltarief in de avond, nacht en weekend. Daltarief is meestal goedkoper.'
        }
      ]
    },
    {
      id: 'contracts',
      title: 'Contracten & Wijzigingen',
      icon: FileText,
      color: 'bg-purple-500/10 text-purple-600',
      faqs: [
        {
          question: 'Kan ik mijn contract tussentijds opzeggen?',
          answer: 'Dit hangt af van je contracttype. Bij vaste contracten kun je meestal alleen opzeggen bij verhuizing of na de looptijd. Variabele contracten hebben vaak kortere opzegtermijnen.'
        },
        {
          question: 'Hoe wijzig ik mijn maandelijkse termijnbedrag?',
          answer: 'Log in op je online account of neem contact op met de klantenservice. Je kunt je termijnbedrag aanpassen aan je verwachte verbruik.'
        },
        {
          question: 'Wat gebeurt er bij een verhuizing?',
          answer: 'Geef je verhuizing minimaal 6 weken van tevoren door. We regelen de eindafrekening en helpen je met je nieuwe aansluiting.'
        }
      ]
    },
    {
      id: 'technical',
      title: 'Technische Vragen',
      icon: Settings,
      color: 'bg-orange-500/10 text-orange-600',
      faqs: [
        {
          question: 'Mijn slimme meter geeft geen data door',
          answer: 'Controleer de verbinding en reset de meter door 10 seconden de knop ingedrukt te houden. Neem contact op als het probleem aanhoudt.'
        },
        {
          question: 'Hoe werkt de teruglevering van zonnepanelen?',
          answer: 'Overschot wordt automatisch teruggeleverd aan het net. Je ziet dit als negatief verbruik op je meter en factuur.'
        },
        {
          question: 'Wat te doen bij een stroomstoring?',
          answer: 'Controleer eerst je zekeringkast. Bij gebiedsbrede storingen, meld dit via de storingsdienst van je netbeheerder.'
        }
      ]
    }
  ];

  const handleTalkToHuman = () => {
    // Placeholder for human chat functionality
    alert('Je wordt doorverbonden naar een medewerker. Deze functie wordt binnenkort beschikbaar.');
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <Card className="bg-gradient-to-r from-energy-green/10 via-energy-blue/10 to-purple-500/10 border-0">
        <CardHeader className="text-center pb-6">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-white rounded-full shadow-lg">
              <HelpCircle className="h-8 w-8 text-energy-green" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold mb-2">Veelgestelde Vragen</CardTitle>
          <p className="text-muted-foreground">
            Vind snel antwoorden op je vragen of chat met onze AI-assistent
          </p>
        </CardHeader>
      </Card>

      {/* Interactive Help Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card 
          className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-105 bg-gradient-to-br from-energy-green/5 to-energy-blue/10 border border-energy-green/20"
          onClick={onOpenChatBot}
        >
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-energy-green/10 rounded-full">
                <Bot className="h-8 w-8 text-energy-green" />
              </div>
            </div>
            <h3 className="font-semibold text-lg mb-2 flex items-center justify-center gap-2">
              <Sparkles className="h-5 w-5 text-energy-green" />
              AI Energie-assistent
            </h3>
            <p className="text-muted-foreground text-sm mb-4">
              Stel je vraag aan onze slimme assistent voor direct antwoord
            </p>
            <Badge variant="secondary" className="bg-energy-green/10 text-energy-green">
              Nog vragen? Klik hier!
            </Badge>
          </CardContent>
        </Card>

        <Card 
          className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-105 bg-gradient-to-br from-blue-500/5 to-purple-500/10 border border-blue-500/20"
          onClick={handleTalkToHuman}
        >
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-blue-500/10 rounded-full">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
            </div>
            <h3 className="font-semibold text-lg mb-2 flex items-center justify-center gap-2">
              <Phone className="h-5 w-5 text-blue-600" />
              Menselijke medewerker
            </h3>
            <p className="text-muted-foreground text-sm mb-4">
              Persoonlijk contact met onze energiespecialisten
            </p>
            <Badge variant="secondary" className="bg-blue-500/10 text-blue-600">
              Direct contact
            </Badge>
          </CardContent>
        </Card>
      </div>

      {/* FAQ Categories */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {faqCategories.map((category) => {
          const IconComponent = category.icon;
          return (
            <Card 
              key={category.id}
              className="cursor-pointer hover:shadow-md transition-all duration-200"
            >
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-3 text-lg">
                  <div className={`p-2 rounded-lg ${category.color}`}>
                    <IconComponent className="h-5 w-5" />
                  </div>
                  {category.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {category.faqs.map((faq, index) => (
                    <AccordionItem key={index} value={`${category.id}-${index}`}>
                      <AccordionTrigger className="text-left text-sm">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-sm text-muted-foreground">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Bottom CTA */}
      <Card className="bg-gradient-to-r from-energy-green/5 to-energy-blue/5 border border-energy-green/20">
        <CardContent className="p-6 text-center">
          <h3 className="font-semibold mb-2">Geen antwoord gevonden?</h3>
          <p className="text-muted-foreground text-sm mb-4">
            Onze AI-assistent staat 24/7 voor je klaar met persoonlijke hulp
          </p>
          <Button 
            onClick={onOpenChatBot}
            className="bg-gradient-to-r from-energy-green to-energy-blue text-white hover:scale-105 transition-transform"
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            Start chat met AI-assistent
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default FAQ;