import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { LineChart, Line, BarChart, Bar, ComposedChart, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { useEnergyPrices } from "@/hooks/useEnergyPrices";
import { TrendingUp, TrendingDown, Minus, RefreshCw } from "lucide-react";
import ProfileSettings from "./ProfileSettings";
import Sparky from "./Sparky";
import FloatingTopBar from "./FloatingTopBar";
import FAQ from "./FAQ";
import SmartMeterCard from "./SmartMeterCard";
import ContractSelector from "./ContractSelector";
import { format, isToday, isTomorrow, isYesterday, startOfDay } from "date-fns";
import { nl } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";
import { 
  Zap, 
  Euro, 
  FileText, 
  Settings,
  Home,
  BarChart3,
  Clock,
  Download,
  User,
  Calendar,
  HelpCircle,
  Edit,
  Lock,
  CreditCard,
  MapPin,
  Mail,
  UserCog,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const EnergyDashboard = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [selectedDay, setSelectedDay] = useState("today");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [includeVat, setIncludeVat] = useState(true);
  const [energyType, setEnergyType] = useState<'electricity' | 'gas'>('electricity');
  const [priceType, setPriceType] = useState<'energy' | 'imbalance'>('energy');
  const [consumptionPeriod, setConsumptionPeriod] = useState<'day' | 'week' | 'month'>('day');
  const [costSelectedDate, setCostSelectedDate] = useState<Date>(new Date());
  const [costViewType, setCostViewType] = useState<'consumption' | 'feedin'>('consumption');
  const [selectedContractId, setSelectedContractId] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  
  // Check authentication status
  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setIsAuthenticated(!!session);
      setIsCheckingAuth(false);
    };
    
    checkAuth();
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setIsAuthenticated(!!session);
    });
    
    return () => subscription.unsubscribe();
  }, []);
  
  // Kostenoverzicht filters
  const [costFilters, setCostFilters] = useState({
    energiePrijs: true,
    inkoopVergoeding: true,
    netbeheerKosten: true,
    overheidsheffingen: true,
    vasteLeveringskosten: true,
    btw: true,
  });
  
  // Real-time energy prices
  const { data: energyPrices, loading: pricesLoading, error: pricesError, lastUpdated, refetch } = useEnergyPrices();

  // Mock data voor demo
  const currentUsage = 2.4; // kW
  const todayCost = 12.45; // €
  const monthlyBudget = 120; // €
  const currentProgress = (todayCost / (monthlyBudget / 30)) * 100;

  // Genereer realistische Nederlandse energieprijzen per kwartier (excl. BTW) gebaseerd op EPEX marktprijzen
  const generateQuarterHourData = (baseHourPrices: number[]) => {
    const quarterData = [];
    for (let hour = 0; hour < 24; hour++) {
      const currentPrice = baseHourPrices[hour];
      const nextPrice = baseHourPrices[(hour + 1) % 24];
      const variation = (Math.random() - 0.5) * 0.01; // Kleine variatie tussen kwartieren
      
      for (let quarter = 0; quarter < 4; quarter++) {
        const minutes = quarter * 15;
        const timeString = `${hour.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        const interpolatedPrice = currentPrice + ((nextPrice - currentPrice) * quarter / 4);
        quarterData.push({
          hour: timeString,
          price: interpolatedPrice + variation,
          time: hour * 4 + quarter
        });
      }
    }
    return quarterData;
  };

  const yesterdayHourPrices = [0.089, 0.078, -0.015, -0.028, -0.035, 0.012, 0.095, 0.165, 0.195, 0.145, 0.125, 0.105, 0.085, 0.072, -0.008, 0.075, 0.115, 0.185, 0.245, 0.285, 0.215, 0.155, 0.115, 0.095];
  
  const baseElectricityData = {
    yesterday: generateQuarterHourData(yesterdayHourPrices),
    today: generateQuarterHourData([0.092, 0.081, -0.012, -0.025, -0.042, 0.015, 0.098, 0.172, 0.205, 0.152, 0.132, 0.108, 0.088, 0.075, -0.005, 0.078, 0.118, 0.192, 0.258, 0.295, 0.225, 0.162, 0.122, 0.098]),
    tomorrow: generateQuarterHourData([0.085, 0.074, -0.018, -0.031, -0.038, 0.009, 0.091, 0.158, 0.188, 0.138, 0.118, 0.095, 0.078, 0.065, -0.012, 0.068, 0.105, 0.175, 0.235, 0.272, 0.202, 0.145, 0.108, 0.088])
  };

  // Realistische Nederlandse gasprijzen (excl. BTW) per m³
  const baseGasData = {
    yesterday: generateQuarterHourData([0.85, 0.84, 0.82, 0.81, 0.80, 0.81, 0.86, 0.92, 0.95, 0.93, 0.90, 0.88, 0.86, 0.84, 0.83, 0.85, 0.89, 0.94, 0.98, 1.02, 0.96, 0.91, 0.88, 0.86]),
    today: generateQuarterHourData([0.87, 0.86, 0.84, 0.83, 0.82, 0.83, 0.88, 0.94, 0.97, 0.95, 0.92, 0.90, 0.88, 0.86, 0.85, 0.87, 0.91, 0.96, 1.00, 1.04, 0.98, 0.93, 0.90, 0.88]),
    tomorrow: generateQuarterHourData([0.83, 0.82, 0.80, 0.79, 0.78, 0.79, 0.84, 0.90, 0.93, 0.91, 0.88, 0.86, 0.84, 0.82, 0.81, 0.83, 0.87, 0.92, 0.96, 1.00, 0.94, 0.89, 0.86, 0.84])
  };

  // Realistische Nederlandse onbalansprijzen (excl. BTW) per kWh
  // Onbalansprijzen zijn volatieler en kunnen hoger of lager zijn dan energieprijzen, inclusief negatieve prijzen
  const baseImbalanceData = {
    yesterday: generateQuarterHourData([0.095, 0.082, -0.025, -0.045, -0.058, 0.020, 0.115, 0.195, 0.235, 0.165, 0.145, 0.122, 0.098, 0.085, -0.018, 0.092, 0.135, 0.215, 0.285, 0.325, 0.245, 0.175, 0.135, 0.108]),
    today: generateQuarterHourData([0.102, 0.088, -0.032, -0.052, -0.065, 0.028, 0.125, 0.208, 0.252, 0.178, 0.155, 0.128, 0.105, 0.092, -0.022, 0.098, 0.142, 0.228, 0.298, 0.345, 0.258, 0.188, 0.145, 0.115]),
    tomorrow: generateQuarterHourData([0.092, 0.078, -0.028, -0.048, -0.062, 0.018, 0.108, 0.188, 0.225, 0.158, 0.138, 0.112, 0.092, 0.078, -0.015, 0.085, 0.125, 0.202, 0.268, 0.312, 0.232, 0.165, 0.125, 0.098])
  };

  // Bereken prijzen inclusief of exclusief BTW
  const basePriceData = priceType === 'imbalance' 
    ? baseImbalanceData 
    : (energyType === 'electricity' ? baseElectricityData : baseGasData);
  const priceData = Object.keys(basePriceData).reduce((acc, day) => {
    acc[day as keyof typeof basePriceData] = basePriceData[day as keyof typeof basePriceData].map(item => ({
      ...item,
      price: includeVat ? item.price * 1.21 : item.price
    }));
    return acc;
  }, {} as typeof basePriceData);

  const currentHour = new Date().getHours();
  const currentQuarter = Math.floor(new Date().getMinutes() / 15);
  const currentTimeIndex = currentHour * 4 + currentQuarter;
  const currentPrice = priceData.today[currentTimeIndex]?.price || 0;
  const priceUnit = (priceType === 'imbalance' || energyType === 'electricity') ? 'kWh' : 'm³';
  
  // Check if tomorrow prices are available
  const isTomorrowAvailable = () => {
    const now = new Date();
    const currentHour = now.getHours();
    if (energyType === 'electricity') {
      return currentHour >= 15; // Electricity prices available from 15:00
    } else {
      return currentHour >= 18; // Gas prices available from 18:00
    }
  };
  
  const tomorrowAvailable = isTomorrowAvailable();
  
  // Bepaal welke dag data te tonen op basis van geselecteerde datum
  const getDashboardSelectedDay = () => {
    if (isYesterday(selectedDate)) return 'yesterday';
    if (isToday(selectedDate)) return 'today';
    if (isTomorrow(selectedDate)) return 'tomorrow';
    // Voor andere datums, gebruik today data als fallback
    return 'today';
  };
  
  const dashboardSelectedDay = getDashboardSelectedDay();
  const selectedDayData = priceData[dashboardSelectedDay as keyof typeof priceData];
  
  const handlePreviousDay = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() - 1);
    setSelectedDate(newDate);
  };
  
  const handleNextDay = () => {
    const newDate = new Date(selectedDate);
    newDate.setDate(newDate.getDate() + 1);
    setSelectedDate(newDate);
  };

  const [invoiceTypeFilter, setInvoiceTypeFilter] = useState<string>('all');

  const recentInvoices = [
    { 
      id: "INV-2024-03", 
      invoiceNumber: "2024-03-001",
      date: "Maart 2024", 
      period: "1 mrt - 31 mrt 2024",
      amount: 125.50, 
      status: "paid",
      type: "maandafrekening",
      dueDate: "15 apr 2024",
      paidDate: "10 apr 2024"
    },
    { 
      id: "INV-2024-02", 
      invoiceNumber: "2024-02-001",
      date: "Februari 2024", 
      period: "1 feb - 29 feb 2024",
      amount: 110.25, 
      status: "paid",
      type: "maandafrekening",
      dueDate: "15 mrt 2024",
      paidDate: "12 mrt 2024"
    },
    { 
      id: "INV-2023-YEAR", 
      invoiceNumber: "2023-JAAR-001",
      date: "Jaarafrekening 2023", 
      period: "1 jan - 31 dec 2023",
      amount: 1450.75, 
      status: "paid",
      type: "jaarafrekening",
      dueDate: "31 jan 2024",
      paidDate: "28 jan 2024"
    },
    { 
      id: "INV-2024-01", 
      invoiceNumber: "2024-01-001",
      date: "Januari 2024", 
      period: "1 jan - 31 jan 2024",
      amount: 135.75, 
      status: "paid",
      type: "maandafrekening",
      dueDate: "15 feb 2024",
      paidDate: "10 feb 2024"
    },
    { 
      id: "INV-2023-END", 
      invoiceNumber: "2023-EIND-001",
      date: "Eindafrekening Contract 2023", 
      period: "1 jan 2023 - 31 dec 2023",
      amount: 245.50, 
      status: "paid",
      type: "eindafrekening",
      dueDate: "15 jan 2024",
      paidDate: "8 jan 2024"
    },
  ];

  const filteredInvoices = invoiceTypeFilter === 'all' 
    ? recentInvoices 
    : recentInvoices.filter(inv => inv.type === invoiceTypeFilter);

  const handleDownloadInvoice = (invoiceId: string) => {
    // Mock download functionality
    console.log('Downloading invoice:', invoiceId);
    // In real implementation, this would download the PDF
  };

  // Genereer verbruik en invoeding data
  const generateConsumptionData = () => {
    if (consumptionPeriod === 'day') {
      // 96 kwartierprijzen (24 uur * 4 kwartieren)
      return Array.from({ length: 96 }, (_, i) => {
        const hour = Math.floor(i / 4);
        const minute = (i % 4) * 15;
        const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
        
        // Verbruik varieert per dagdeel (hoger in ochtend en avond)
        let baseConsumption = 0.3;
        if (hour >= 6 && hour < 9) baseConsumption = 0.8; // Ochtend
        else if (hour >= 17 && hour < 22) baseConsumption = 0.9; // Avond
        else if (hour >= 22 || hour < 6) baseConsumption = 0.2; // Nacht
        
        // Invoeding hoger overdag (zonne-energie)
        let baseFeedIn = 0;
        if (hour >= 9 && hour < 17) baseFeedIn = 0.6; // Dag
        if (hour >= 11 && hour < 15) baseFeedIn = 0.9; // Piek
        
        return {
          label: timeString,
          time: i, // Voor sortering
          verbruik: baseConsumption + (Math.random() * 0.3), // kWh per kwartier
          invoeding: baseFeedIn + (Math.random() * 0.2), // kWh per kwartier
        };
      });
    } else if (consumptionPeriod === 'week') {
      // 7 dagen data
      return Array.from({ length: 7 }, (_, i) => ({
        label: ['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'][i],
        verbruik: Math.random() * 30 + 10, // 10-40 kWh per dag
        invoeding: Math.random() * 20, // 0-20 kWh per dag
      }));
    } else {
      // 30 dagen data
      return Array.from({ length: 30 }, (_, i) => ({
        label: `${i + 1}`,
        verbruik: Math.random() * 35 + 15, // 15-50 kWh per dag
        invoeding: Math.random() * 25 + 5, // 5-30 kWh per dag
      }));
    }
  };

  const consumptionData = generateConsumptionData();

  // Genereer kosten breakdown data voor specifieke dag (96 kwartieren)
  const generateCostData = () => {
    // Genereer 96 kwartierprijzen voor de geselecteerde dag
    return Array.from({ length: 96 }, (_, i) => {
      const hour = Math.floor(i / 4);
      const minute = (i % 4) * 15;
      const timeString = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      
      // Verbruik varieert per dagdeel (hoger in ochtend en avond)
      let verbruikKwh = 0.3;
      if (hour >= 6 && hour < 9) verbruikKwh = 0.8; // Ochtend
      else if (hour >= 17 && hour < 22) verbruikKwh = 0.9; // Avond
      else if (hour >= 22 || hour < 6) verbruikKwh = 0.2; // Nacht
      
      // Voeg wat variatie toe
      verbruikKwh = verbruikKwh + (Math.random() * 0.3);
      
      // Realistische Nederlandse energiekosten per kWh (excl. BTW)
      const energiePrijsPerKwh = 0.25; // Energieprijs
      const inkoopVergoedingPerKwh = 0.03; // Inkoopvergoeding leverancier
      const netbeheerPerKwh = 0.08; // Netbeheerkosten
      const overheidsheffingPerKwh = 0.12; // Energiebelasting en ODE
      const vasteLeveringskostenPerKwartier = 0.50 / 96; // €0.50 per dag verdeeld over 96 kwartieren
      
      // Bereken kosten per component
      const energiePrijs = verbruikKwh * energiePrijsPerKwh;
      const inkoopVergoeding = verbruikKwh * inkoopVergoedingPerKwh;
      const netbeheerKosten = verbruikKwh * netbeheerPerKwh;
      const overheidsheffingen = verbruikKwh * overheidsheffingPerKwh;
      const vasteLeveringskosten = vasteLeveringskostenPerKwartier;
      
      // Bereken subtotaal (excl. BTW)
      let subtotaal = 0;
      if (costFilters.energiePrijs) subtotaal += energiePrijs;
      if (costFilters.inkoopVergoeding) subtotaal += inkoopVergoeding;
      if (costFilters.netbeheerKosten) subtotaal += netbeheerKosten;
      if (costFilters.overheidsheffingen) subtotaal += overheidsheffingen;
      if (costFilters.vasteLeveringskosten) subtotaal += vasteLeveringskosten;
      
      // BTW (21%)
      const btw = subtotaal * 0.21;
      const totaal = subtotaal + (costFilters.btw ? btw : 0);
      
      return {
        label: timeString,
        time: i,
        energiePrijs: costFilters.energiePrijs ? energiePrijs : 0,
        inkoopVergoeding: costFilters.inkoopVergoeding ? inkoopVergoeding : 0,
        netbeheerKosten: costFilters.netbeheerKosten ? netbeheerKosten : 0,
        overheidsheffingen: costFilters.overheidsheffingen ? overheidsheffingen : 0,
        vasteLeveringskosten: costFilters.vasteLeveringskosten ? vasteLeveringskosten : 0,
        btw: costFilters.btw ? btw : 0,
        totaal: totaal,
      };
    });
  };

  const costData = generateCostData();
  
  // Genereer invoeding data
  const generateFeedInData = () => {
    return Array.from({ length: 96 }, (_, i) => {
      const hour = Math.floor(i / 4);
      const minutes = (i % 4) * 15;
      const timeString = `${hour.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      
      // Simuleer invoeding (vooral overdag met zonnepanelen)
      let invoedinKwh = 0;
      if (hour >= 9 && hour < 17) {
        // Piek tussen 11:00 en 15:00
        const sunIntensity = Math.sin(((hour - 6) / 12) * Math.PI);
        invoedinKwh = sunIntensity * (2 + Math.random() * 0.5);
      }
      
      // Terugleverprijs (positief, ongeveer 70% van inkoopprijs)
      const terugleverPrijs = invoedinKwh * 0.18;
      
      // Inkoopvergoeding (negatief, kosten)
      const inkoopVergoeding = invoedinKwh * 0.03;
      
      // Totaal (positief - negatief)
      const totaal = terugleverPrijs - inkoopVergoeding;
      
      return {
        label: timeString,
        time: i,
        terugleverPrijs: terugleverPrijs,
        inkoopVergoeding: -inkoopVergoeding, // Negatief voor staaf naar beneden
        totaal: totaal,
      };
    });
  };
  
  const feedInData = generateFeedInData();

  return (
    <div className="min-h-screen bg-background pt-20 pb-24 md:pt-24 md:pb-6">
      {/* Floating Top Bar */}
      <FloatingTopBar activeTab={activeTab} setActiveTab={setActiveTab} />
      <Sparky />

      <div className="container mx-auto px-3 sm:px-4 py-4 sm:py-6 max-w-7xl">
        {/* Auth prompt when not logged in */}
        {!isAuthenticated && !isCheckingAuth && (
          <Card className="mb-6 border-energy-orange/50 bg-gradient-to-br from-energy-orange/10 to-energy-orange/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Log in om je contracten te bekijken</h3>
                  <p className="text-sm text-muted-foreground">
                    Meld je aan om je contracten te beheren en je verbruik te volgen
                  </p>
                </div>
                <Button onClick={() => navigate('/auth')} size="lg">
                  Inloggen
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Contract Selector - only show when authenticated */}
        {isAuthenticated && (
          <div className="mb-4 sm:mb-6">
            <ContractSelector 
              selectedContractId={selectedContractId}
              onSelectContract={setSelectedContractId}
            />
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-4 sm:space-y-6">
            <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              {/* Current Usage */}
              <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-energy-green/15 to-energy-blue/10 border border-white/20 shadow-lg shadow-energy-green/10">
                <CardHeader className="relative pb-3">
                  <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 text-energy-green drop-shadow-sm" />
                    <span className="text-foreground">Huidig Verbruik</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative">
                  <div className="text-2xl sm:text-3xl font-bold text-energy-green mb-2 drop-shadow-sm">
                    {currentUsage} kW
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground/90 font-medium">
                    Gemiddeld laag verbruik
                  </p>
                </CardContent>
              </Card>

              {/* Today's Cost */}
              <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-energy-orange/15 to-energy-orange/8 border border-white/20 shadow-lg shadow-energy-orange/10">
                <CardHeader className="relative pb-3">
                  <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
                    <Euro className="w-4 h-4 sm:w-5 sm:h-5 text-energy-orange drop-shadow-sm" />
                    <span className="text-foreground">Kosten Vandaag</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative">
                  <div className="text-2xl sm:text-3xl font-bold text-energy-orange mb-2 drop-shadow-sm">
                    €{todayCost}
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground/90 font-medium">
                    {Math.round(currentProgress)}% van dagelijks budget
                  </p>
                </CardContent>
              </Card>

              {/* Monthly Progress */}
              <Card className="relative overflow-hidden sm:col-span-2 lg:col-span-1 backdrop-blur-lg bg-gradient-to-br from-energy-blue/15 to-energy-blue/8 border border-white/20 shadow-lg shadow-energy-blue/10">
                <CardHeader className="relative pb-3">
                  <CardTitle className="flex items-center space-x-2 text-base sm:text-lg">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-energy-blue drop-shadow-sm" />
                    <span className="text-foreground">Maandelijks Budget</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative space-y-3 sm:space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-xl sm:text-2xl font-bold text-foreground drop-shadow-sm">€{monthlyBudget}</span>
                    <Badge variant="secondary" className="backdrop-blur-sm bg-white/20 border border-white/30 text-xs sm:text-sm">75% gebruikt</Badge>
                  </div>
                  <Progress value={75} className="w-full" />
                  <p className="text-xs sm:text-sm text-muted-foreground/90 font-medium">
                    €30 resterend voor deze maand
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Live Hourly Prices */}
            <Card className="relative overflow-hidden backdrop-blur-lg bg-gradient-to-br from-primary/10 via-background to-secondary/10 border border-white/20 shadow-2xl">
              <CardHeader className="pb-3 space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5 text-primary" />
                      <h3 className="text-lg font-semibold">Prijzenoverzicht</h3>
                    </div>
                    <div className="flex gap-2 flex-wrap items-center">
                      {priceType === 'energy' && (
                        <Tabs value={energyType} onValueChange={(value) => setEnergyType(value as 'electricity' | 'gas')} className="w-auto">
                          <TabsList className="h-9">
                            <TabsTrigger value="electricity" className="h-8 px-3">
                              <Zap className="w-3.5 h-3.5 sm:mr-1.5" />
                              <span className="hidden sm:inline">Elektra</span>
                            </TabsTrigger>
                            <TabsTrigger value="gas" className="h-8 px-3">
                              <svg className="w-3.5 h-3.5 sm:mr-1.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>
                              </svg>
                              <span className="hidden sm:inline">Gas</span>
                            </TabsTrigger>
                          </TabsList>
                        </Tabs>
                      )}
                      <div className="flex items-center gap-1.5">
                        <Button
                          variant={includeVat ? "default" : "ghost"}
                          size="sm"
                          onClick={() => setIncludeVat(true)}
                          className="h-8 px-3 text-xs"
                        >
                          Incl. BTW
                        </Button>
                        <Button
                          variant={!includeVat ? "default" : "ghost"}
                          size="sm"
                          onClick={() => setIncludeVat(false)}
                          className="h-8 px-3 text-xs"
                        >
                          Excl. BTW
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col items-end gap-2">
                    <Tabs value={priceType} onValueChange={(value) => setPriceType(value as 'energy' | 'imbalance')} className="w-auto">
                      <TabsList className="h-9">
                        <TabsTrigger value="energy" className="h-8 px-3">
                          <Euro className="w-3.5 h-3.5 sm:mr-1.5" />
                          <span className="hidden sm:inline">Energieprijzen</span>
                        </TabsTrigger>
                        <TabsTrigger value="imbalance" className="h-8 px-3">
                          <TrendingUp className="w-3.5 h-3.5 sm:mr-1.5" />
                          <span className="hidden sm:inline">Onbalansprijzen</span>
                        </TabsTrigger>
                      </TabsList>
                    </Tabs>
                    {isToday(selectedDate) && (
                      <div className="text-sm whitespace-nowrap">
                        <span className="text-muted-foreground">Nu: </span>
                        <span className="font-bold text-energy-orange">€{currentPrice.toFixed(3)}/{priceUnit}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handlePreviousDay}
                      className="h-8 w-8 p-0"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "h-8 justify-start text-left font-normal",
                            "min-w-[140px]"
                          )}
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          {format(selectedDate, "d MMM yyyy", { locale: nl })}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="center">
                        <CalendarComponent
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          initialFocus
                          locale={nl}
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleNextDay}
                      className="h-8 w-8 p-0"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                {isTomorrow(selectedDate) && !tomorrowAvailable ? (
                  <div className="h-80 mb-6 rounded-xl overflow-hidden bg-gradient-to-b from-background/50 to-muted/30 p-4 flex items-center justify-center">
                      <div className="text-center space-y-4">
                        <Lock className="w-16 h-16 mx-auto text-muted-foreground/40" />
                        <div>
                          <h3 className="text-xl font-semibold mb-2">Prijzen nog niet beschikbaar</h3>
                          <p className="text-muted-foreground">
                            De {priceType === 'imbalance' ? 'onbalansprijzen' : (energyType === 'electricity' ? 'elektriciteitsprijzen' : 'gasprijzen')} voor morgen zijn beschikbaar vanaf{' '}
                            <span className="font-bold text-primary">{energyType === 'electricity' ? '15:00' : '18:00'}</span> uur
                          </p>
                        </div>
                      </div>
                  </div>
                ) : (
                  <div className="h-64 sm:h-80 lg:h-96 mb-6 rounded-xl overflow-hidden bg-gradient-to-b from-background/50 to-muted/30 p-4">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart 
                        data={selectedDayData} 
                        margin={{ top: 10, right: 5, left: -20, bottom: 5 }}
                      >
                      <defs>
                        <linearGradient id="barGradientGreen" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="hsl(var(--energy-green))" stopOpacity={0.9}/>
                          <stop offset="100%" stopColor="hsl(var(--energy-green))" stopOpacity={0.6}/>
                        </linearGradient>
                        <linearGradient id="barGradientOrange" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="hsl(var(--energy-orange))" stopOpacity={0.9}/>
                          <stop offset="100%" stopColor="hsl(var(--energy-orange))" stopOpacity={0.6}/>
                        </linearGradient>
                        <linearGradient id="barGradientRed" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.9}/>
                          <stop offset="100%" stopColor="hsl(0, 84%, 60%)" stopOpacity={0.6}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                      <XAxis 
                        dataKey="hour" 
                        interval={11}
                        tick={{ fontSize: 10, fill: 'hsl(var(--foreground))' }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickLine={false}
                      />
                      <YAxis 
                        tick={{ fontSize: 10, fill: 'hsl(var(--foreground))' }}
                        label={{ value: `€/${priceUnit}`, angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: 'hsl(var(--foreground))', fontSize: 10 } }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickLine={false}
                        domain={['auto', 'auto']}
                        width={40}
                      />
                      <Tooltip 
                        cursor={{ fill: 'hsl(var(--primary) / 0.1)' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0];
                            const isCurrentHour = data.payload.time === currentTimeIndex;
                            return (
                              <div className="bg-card/95 backdrop-blur-xl border-2 border-primary/50 rounded-xl p-4 shadow-2xl">
                                 <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                                  {isCurrentHour && <span className="w-2 h-2 rounded-full bg-energy-orange animate-pulse" />}
                                  {data.payload.hour} {isCurrentHour && '(Nu)'}
                                </p>
                                <p className={`text-lg font-bold ${(data.value as number) < 0 ? 'text-energy-green' : 'text-primary'}`}>
                                  €{(data.value as number).toFixed(3)} /{priceUnit}
                                </p>
                                {(data.value as number) < 0 && (
                                  <p className="text-xs text-energy-green font-medium mt-1">
                                    Je krijgt geld terug!
                                  </p>
                                )}
                                <p className="text-xs text-muted-foreground mt-1">
                                  {includeVat ? 'Inclusief BTW' : 'Exclusief BTW'}
                                </p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar 
                        dataKey="price" 
                        radius={[8, 8, 0, 0]}
                        animationDuration={1000}
                      >
                        {selectedDayData.map((entry, index) => {
                          const isCurrentHour = dashboardSelectedDay === 'today' && entry.time === currentTimeIndex;
                          
                          // Bepaal kleur op basis van energietype
                          const fillColor = energyType === 'gas' 
                            ? "hsl(200, 76%, 36%)" 
                            : "url(#barGradientGreen)";
                          
                          return (
                            <Cell 
                              key={`cell-${index}`} 
                              fill={fillColor}
                              stroke={isCurrentHour ? "hsl(var(--energy-orange))" : "transparent"}
                              strokeWidth={isCurrentHour ? 3 : 0}
                              className="transition-all duration-300 hover:opacity-80"
                            />
                          );
                        })}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                )}
                
                {/* Price statistics for selected day */}
                <div className="grid gap-4 md:grid-cols-3">
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-energy-green">
                          €{Math.min(...selectedDayData.map(p => p.price)).toFixed(3)}
                        </div>
                        <p className="text-sm text-muted-foreground">Laagste prijs</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-energy-orange">
                          €{Math.max(...selectedDayData.map(p => p.price)).toFixed(3)}
                        </div>
                        <p className="text-sm text-muted-foreground">Hoogste prijs</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-energy-blue">
                          €{(selectedDayData.reduce((sum, p) => sum + p.price, 0) / selectedDayData.length).toFixed(3)}
                        </div>
                        <p className="text-sm text-muted-foreground">Gemiddelde</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Quarter Hour Prices Tab */}
          <TabsContent value="prices" className="space-y-6">
            {/* Day Selection */}
            <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
              <CardHeader>
                <CardTitle className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-primary" />
                    <span>Kwartierprijzen</span>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="text-xs sm:text-sm text-muted-foreground">
                      Huidige prijs: <span className="font-bold text-energy-orange">€{currentPrice.toFixed(3)}/{priceUnit}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Button
                        variant={includeVat ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setIncludeVat(true)}
                        className="h-8 px-2 sm:px-3 text-xs"
                      >
                        Incl.
                      </Button>
                      <Button
                        variant={!includeVat ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setIncludeVat(false)}
                        className="h-8 px-2 sm:px-3 text-xs"
                      >
                        Excl.
                      </Button>
                    </div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={selectedDay} onValueChange={setSelectedDay} className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-4 sm:mb-6">
                    <TabsTrigger value="yesterday" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm">
                      <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                      <span>Gisteren</span>
                    </TabsTrigger>
                    <TabsTrigger value="today" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm">
                      <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                      <span>Vandaag</span>
                    </TabsTrigger>
                    <TabsTrigger value="tomorrow" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm">
                      <Calendar className="w-3 h-3 sm:w-4 sm:h-4" />
                      <span>Morgen</span>
                    </TabsTrigger>
                  </TabsList>

                  {Object.keys(priceData).map((day) => (
                    <TabsContent key={day} value={day}>
                      {/* Price Chart */}
                      <div className="h-[250px] sm:h-[300px] lg:h-80 mb-4 sm:mb-6 rounded-xl overflow-hidden bg-gradient-to-b from-background/50 to-muted/30 p-4">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart 
                            data={priceData[day as keyof typeof priceData]}
                            margin={{ top: 10, right: 5, left: -20, bottom: 5 }}
                          >
                            <defs>
                              <linearGradient id="barGradientGreen" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="hsl(var(--energy-green))" stopOpacity={0.9}/>
                                <stop offset="100%" stopColor="hsl(var(--energy-green))" stopOpacity={0.6}/>
                              </linearGradient>
                              <linearGradient id="barGradientOrange" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="hsl(var(--energy-orange))" stopOpacity={0.9}/>
                                <stop offset="100%" stopColor="hsl(var(--energy-orange))" stopOpacity={0.6}/>
                              </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                            <XAxis 
                              dataKey="hour" 
                              interval={11}
                              tick={{ fontSize: 10, fill: 'hsl(var(--foreground))' }}
                              axisLine={{ stroke: 'hsl(var(--border))' }}
                              tickLine={false}
                            />
                            <YAxis 
                              tick={{ fontSize: 10, fill: 'hsl(var(--foreground))' }}
                              label={{ value: `€/${priceUnit}`, angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: 'hsl(var(--foreground))', fontSize: 10 } }}
                              axisLine={{ stroke: 'hsl(var(--border))' }}
                              tickLine={false}
                              domain={['auto', 'auto']}
                              width={40}
                            />
                            <Tooltip 
                              cursor={{ fill: 'hsl(var(--primary) / 0.1)' }}
                              content={({ active, payload }) => {
                                if (active && payload && payload.length) {
                                  const data = payload[0];
                                  const isCurrentHour = day === 'today' && data.payload.time === currentTimeIndex;
                                  return (
                                    <div className="bg-card/95 backdrop-blur-xl border-2 border-primary/50 rounded-xl p-4 shadow-2xl">
                                      <p className="text-sm font-semibold mb-2 flex items-center gap-2">
                                        {isCurrentHour && <span className="w-2 h-2 rounded-full bg-energy-orange animate-pulse" />}
                                        {data.payload.hour} {isCurrentHour && '(Nu)'}
                                      </p>
                                      <p className={`text-lg font-bold ${(data.value as number) < 0 ? 'text-energy-green' : 'text-primary'}`}>
                                        €{(data.value as number).toFixed(3)} /{priceUnit}
                                      </p>
                                      {(data.value as number) < 0 && (
                                        <p className="text-xs text-energy-green font-medium mt-1">
                                          Je krijgt geld terug!
                                        </p>
                                      )}
                                      <p className="text-xs text-muted-foreground mt-1">
                                        {includeVat ? 'Inclusief BTW' : 'Exclusief BTW'}
                                      </p>
                                    </div>
                                  );
                                }
                                return null;
                              }}
                            />
                            <Bar 
                              dataKey="price" 
                              radius={[8, 8, 0, 0]}
                              animationDuration={1000}
                            >
                              {priceData[day as keyof typeof priceData].map((entry, index) => {
                                const isCurrentHour = day === 'today' && entry.time === currentTimeIndex;
                                
                                return (
                                  <Cell 
                                    key={`cell-${index}`} 
                                    fill="url(#barGradientGreen)"
                                    stroke={isCurrentHour ? "hsl(var(--energy-orange))" : "transparent"}
                                    strokeWidth={isCurrentHour ? 3 : 0}
                                    className="transition-all duration-300 hover:opacity-80"
                                  />
                                );
                              })}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      {/* Price Statistics */}
                      <div className="grid gap-3 sm:gap-4 grid-cols-3 mb-4 sm:mb-6">
                        <Card>
                          <CardContent className="p-3 sm:p-4">
                            <div className="text-center">
                              <div className="text-lg sm:text-2xl font-bold text-energy-green">
                                €{Math.min(...priceData[day as keyof typeof priceData].map(p => p.price)).toFixed(3)}
                              </div>
                              <p className="text-xs sm:text-sm text-muted-foreground">Laagste</p>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-3 sm:p-4">
                            <div className="text-center">
                              <div className="text-lg sm:text-2xl font-bold text-energy-orange">
                                €{Math.max(...priceData[day as keyof typeof priceData].map(p => p.price)).toFixed(3)}
                              </div>
                              <p className="text-xs sm:text-sm text-muted-foreground">Hoogste</p>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-3 sm:p-4">
                            <div className="text-center">
                              <div className="text-lg sm:text-2xl font-bold text-energy-blue">
                                €{(priceData[day as keyof typeof priceData].reduce((sum, p) => sum + p.price, 0) / priceData[day as keyof typeof priceData].length).toFixed(3)}
                              </div>
                              <p className="text-xs sm:text-sm text-muted-foreground">Gemiddeld</p>
                            </div>
                          </CardContent>
                        </Card>
                      </div>

                      {/* Quarter Hour Price List */}
                      <div className="grid gap-1.5 sm:gap-2 max-h-[400px] overflow-y-auto pr-2">
                        {priceData[day as keyof typeof priceData].map((item, index) => (
                          <div 
                            key={`${day}-${item.hour}-${index}`}
                            className={`flex justify-between items-center p-2 sm:p-3 rounded-lg border transition-colors ${
                              day === 'today' && index === currentTimeIndex 
                                ? 'bg-energy-orange-light border-energy-orange' 
                                : 'hover:bg-muted/50'
                            }`}
                          >
                            <div className="flex items-center gap-1.5 sm:gap-2">
                              <Clock className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                              <span className="font-medium text-xs sm:text-sm">{item.hour}</span>
                              {day === 'today' && index === currentTimeIndex && (
                                <Badge variant="secondary" className="bg-energy-orange text-white text-xs px-1.5 py-0">
                                  Nu
                                </Badge>
                              )}
                            </div>
                            <div className="text-right">
                              <div className="text-sm sm:text-base font-bold">
                                €{item.price.toFixed(3)}
                              </div>
                              <div className="text-[10px] sm:text-xs text-muted-foreground">
                                {includeVat ? 'incl. BTW' : 'excl. BTW'}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  ))}
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Usage Tab */}
          <TabsContent value="usage" className="space-y-6">
            {/* Live Smart Meter Data */}
            <SmartMeterCard contractId={selectedContractId} />
            
            {/* Verbruik en Invoeding Grafiek */}
            <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    <span>Verbruik & Invoeding</span>
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button
                      variant={consumptionPeriod === 'day' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setConsumptionPeriod('day')}
                    >
                      Dag
                    </Button>
                    <Button
                      variant={consumptionPeriod === 'week' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setConsumptionPeriod('week')}
                    >
                      Week
                    </Button>
                    <Button
                      variant={consumptionPeriod === 'month' ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setConsumptionPeriod('month')}
                    >
                      Maand
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="h-64 sm:h-80 lg:h-[400px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart 
                      data={consumptionData}
                      margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis 
                        dataKey="label" 
                        className="text-xs"
                        tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                        interval={consumptionPeriod === 'day' ? 11 : 'preserveStartEnd'}
                        angle={consumptionPeriod === 'day' ? -45 : 0}
                        textAnchor={consumptionPeriod === 'day' ? 'end' : 'middle'}
                        height={consumptionPeriod === 'day' ? 50 : 30}
                      />
                      <YAxis 
                        className="text-xs"
                        tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                        width={40}
                        label={{ 
                          value: 'kWh', 
                          angle: -90, 
                          position: 'insideLeft',
                          style: { fill: 'hsl(var(--muted-foreground))', fontSize: 10 }
                        }}
                      />
                      <Tooltip 
                        contentStyle={{
                          backgroundColor: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                          fontSize: '12px'
                        }}
                        formatter={(value: number) => `${value.toFixed(2)} kWh`}
                      />
                      <Bar 
                        dataKey="verbruik" 
                        fill="hsl(var(--energy-orange))" 
                        name="Verbruik"
                        radius={[4, 4, 0, 0]}
                      />
                      <Bar 
                        dataKey="invoeding" 
                        fill="hsl(var(--energy-green))" 
                        name="Invoeding"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-6 flex justify-center gap-6">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: 'hsl(var(--energy-orange))' }} />
                    <span className="text-sm text-muted-foreground">Verbruik</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded" style={{ backgroundColor: 'hsl(var(--energy-green))' }} />
                    <span className="text-sm text-muted-foreground">Invoeding (teruglevering)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Kostenoverzicht Grafiek */}
            <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
              <CardHeader>
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-4">
                    <CardTitle className="flex items-center space-x-2">
                      <Euro className="w-5 h-5 text-primary" />
                      <span>Kostenoverzicht</span>
                    </CardTitle>
                    <div className="flex gap-2">
                      <Button
                        variant={costViewType === 'consumption' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setCostViewType('consumption')}
                      >
                        Afname
                      </Button>
                      <Button
                        variant={costViewType === 'feedin' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setCostViewType('feedin')}
                      >
                        Invoeding
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newDate = new Date(costSelectedDate);
                        newDate.setDate(newDate.getDate() - 1);
                        setCostSelectedDate(newDate);
                      }}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm" className={cn("justify-start text-left font-normal min-w-[140px]")}>
                          <Calendar className="mr-2 h-4 w-4" />
                          {format(costSelectedDate, "d MMM yyyy", { locale: nl })}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="center">
                        <CalendarComponent
                          mode="single"
                          selected={costSelectedDate}
                          onSelect={(date) => date && setCostSelectedDate(date)}
                          initialFocus
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const newDate = new Date(costSelectedDate);
                        newDate.setDate(newDate.getDate() + 1);
                        setCostSelectedDate(newDate);
                      }}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {costViewType === 'consumption' ? (
                  // Afname kosten weergave
                  <div className="flex flex-col lg:flex-row gap-6">
                    {/* Grafiek */}
                    <div className="flex-1">
                      <div className="h-64 sm:h-80 lg:h-[400px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart 
                            data={costData}
                            margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                          >
                          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                          <XAxis 
                            dataKey="label" 
                            className="text-xs"
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                            interval={11}
                            angle={-45}
                            textAnchor="end"
                            height={50}
                          />
                          <YAxis 
                            className="text-xs"
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                            width={40}
                            label={{ 
                              value: '€', 
                              angle: -90, 
                              position: 'insideLeft',
                              style: { fill: 'hsl(var(--muted-foreground))', fontSize: 10 }
                            }}
                          />
                          <Tooltip 
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                              fontSize: '12px'
                            }}
                            formatter={(value: number) => `€${value.toFixed(3)}`}
                          />
                          {costFilters.energiePrijs && (
                            <Bar 
                              dataKey="energiePrijs" 
                              stackId="a"
                              fill="#ef4444" 
                              name="Energieprijs"
                              radius={[0, 0, 0, 0]}
                            />
                          )}
                          {costFilters.inkoopVergoeding && (
                            <Bar 
                              dataKey="inkoopVergoeding" 
                              stackId="a"
                              fill="#3b82f6" 
                              name="Inkoopvergoeding"
                              radius={[0, 0, 0, 0]}
                            />
                          )}
                          {costFilters.netbeheerKosten && (
                            <Bar 
                              dataKey="netbeheerKosten" 
                              stackId="a"
                              fill="#a855f7" 
                              name="Netbeheerkosten"
                              radius={[0, 0, 0, 0]}
                            />
                          )}
                          {costFilters.overheidsheffingen && (
                            <Bar 
                              dataKey="overheidsheffingen" 
                              stackId="a"
                              fill="#14b8a6" 
                              name="Overheidsheffingen"
                              radius={[0, 0, 0, 0]}
                            />
                          )}
                          {costFilters.vasteLeveringskosten && (
                            <Bar 
                              dataKey="vasteLeveringskosten" 
                              stackId="a"
                              fill="#f59e0b" 
                              name="Vaste leveringskosten"
                              radius={[0, 0, 0, 0]}
                            />
                          )}
                          {costFilters.btw && (
                            <Bar 
                              dataKey="btw" 
                              stackId="a"
                              fill="#6b7280" 
                              name="BTW (21%)"
                              radius={[4, 4, 0, 0]}
                            />
                          )}
                        </BarChart>
                      </ResponsiveContainer>
                      </div>
                    </div>
                    
                    {/* Legenda met checkboxes */}
                    <div className="lg:w-64 space-y-3">
                      <h3 className="text-sm font-semibold mb-4">Legenda</h3>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="energiePrijs"
                          checked={costFilters.energiePrijs}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, energiePrijs: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#ef4444' }} />
                          <label htmlFor="energiePrijs" className="text-sm cursor-pointer">
                            Energieprijs
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="inkoopVergoeding"
                          checked={costFilters.inkoopVergoeding}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, inkoopVergoeding: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#3b82f6' }} />
                          <label htmlFor="inkoopVergoeding" className="text-sm cursor-pointer">
                            Inkoopvergoeding
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="netbeheerKosten"
                          checked={costFilters.netbeheerKosten}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, netbeheerKosten: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#a855f7' }} />
                          <label htmlFor="netbeheerKosten" className="text-sm cursor-pointer">
                            Netbeheerkosten
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="overheidsheffingen"
                          checked={costFilters.overheidsheffingen}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, overheidsheffingen: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#14b8a6' }} />
                          <label htmlFor="overheidsheffingen" className="text-sm cursor-pointer">
                            Overheidsheffingen
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="vasteLeveringskosten"
                          checked={costFilters.vasteLeveringskosten}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, vasteLeveringskosten: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#f59e0b' }} />
                          <label htmlFor="vasteLeveringskosten" className="text-sm cursor-pointer">
                            Vaste leveringskosten
                          </label>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <Checkbox 
                          id="btw"
                          checked={costFilters.btw}
                          onCheckedChange={(checked) => 
                            setCostFilters({...costFilters, btw: checked as boolean})
                          }
                        />
                        <div className="flex items-center gap-2 flex-1">
                          <div className="w-4 h-4 rounded" style={{ backgroundColor: '#6b7280' }} />
                          <label htmlFor="btw" className="text-sm cursor-pointer">
                            BTW (21%)
                          </label>
                        </div>
                      </div>
                      
                      <div className="pt-4 mt-4 border-t border-border">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-semibold">Totaal bedrag:</span>
                          <span className="text-lg font-bold text-primary">
                            €{costData.reduce((sum, item) => sum + item.totaal, 0).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  // Invoeding kosten/opbrengsten weergave
                  <div>
                    <div className="h-64 sm:h-80 lg:h-96 mb-6">
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart 
                          data={feedInData}
                          margin={{ top: 5, right: 5, left: -20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                          <XAxis 
                            dataKey="label"
                            className="text-xs"
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                            interval={11}
                            angle={-45}
                            textAnchor="end"
                            height={50}
                          />
                          <YAxis 
                            className="text-xs"
                            tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
                            width={40}
                            label={{ 
                              value: '€', 
                              angle: -90, 
                              position: 'insideLeft',
                              style: { fill: 'hsl(var(--muted-foreground))', fontSize: 10 }
                            }}
                          />
                          <Tooltip 
                            contentStyle={{
                              backgroundColor: 'hsl(var(--popover))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                              fontSize: '12px'
                            }}
                            formatter={(value: number) => `€${Math.abs(value).toFixed(3)}`}
                          />
                          {/* Teruglevering (positief, groen) */}
                          <Bar 
                            dataKey="terugleverPrijs" 
                            fill="hsl(var(--energy-green))" 
                            name="Teruglevering"
                            radius={[4, 4, 0, 0]}
                          />
                          {/* Inkoopvergoeding (negatief, rood) */}
                          <Bar 
                            dataKey="inkoopVergoeding" 
                            fill="#ef4444" 
                            name="Inkoopvergoeding"
                            radius={[0, 0, 4, 4]}
                          />
                          {/* Totaal lijn */}
                          <Line 
                            type="monotone" 
                            dataKey="totaal" 
                            stroke="hsl(var(--energy-blue))" 
                            strokeWidth={3}
                            dot={false}
                            name="Totaal"
                          />
                        </ComposedChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="flex flex-col gap-4 p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded bg-[hsl(var(--energy-green))]" />
                        <span className="text-sm">Teruglevering (inkomsten)</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded bg-[#ef4444]" />
                        <span className="text-sm">Inkoopvergoeding (kosten)</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="w-4 h-4 rounded bg-[hsl(var(--energy-blue))]" />
                        <span className="text-sm">Totaal saldo</span>
                      </div>
                      <div className="pt-4 mt-4 border-t border-border">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-semibold">Totaal saldo:</span>
                          <span className="text-lg font-bold text-energy-green">
                            €{feedInData.reduce((sum, item) => sum + item.totaal, 0).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
                <CardHeader>
                  <CardTitle>Verbruik Deze Week</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {['Ma', 'Di', 'Wo', 'Do', 'Vr', 'Za', 'Zo'].map((day, index) => (
                      <div key={day} className="flex items-center space-x-4">
                        <div className="w-8 text-sm font-medium">{day}</div>
                        <div className="flex-1">
                          <Progress value={Math.random() * 100} className="h-2" />
                        </div>
                        <div className="w-16 text-sm text-right">
                          {(15 + Math.random() * 10).toFixed(1)} kWh
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
                <CardHeader>
                  <CardTitle>Verbruikstrend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-4">
                    <div className="text-4xl font-bold text-energy-blue">
                      18.5 kWh
                    </div>
                    <p className="text-muted-foreground">Gemiddeld per dag</p>
                    <div className="flex justify-center space-x-4 text-sm">
                      <div className="text-center">
                        <div className="text-energy-green font-medium">-5%</div>
                        <div className="text-muted-foreground">vs vorige maand</div>
                      </div>
                      <div className="text-center">
                        <div className="text-energy-orange font-medium">+2%</div>
                        <div className="text-muted-foreground">vs vorig jaar</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Invoices Tab */}
          <TabsContent value="invoices" className="space-y-6">
            {/* Filter Section */}
            <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
              <CardContent className="pt-6">
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={invoiceTypeFilter === 'all' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setInvoiceTypeFilter('all')}
                  >
                    Alle facturen
                  </Button>
                  <Button
                    variant={invoiceTypeFilter === 'maandafrekening' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setInvoiceTypeFilter('maandafrekening')}
                  >
                    Maandafrekening
                  </Button>
                  <Button
                    variant={invoiceTypeFilter === 'jaarafrekening' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setInvoiceTypeFilter('jaarafrekening')}
                  >
                    Jaarafrekening
                  </Button>
                  <Button
                    variant={invoiceTypeFilter === 'eindafrekening' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setInvoiceTypeFilter('eindafrekening')}
                  >
                    Eindafrekening
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Invoices Grid */}
            <div className="grid gap-6 md:grid-cols-2">
              {filteredInvoices.map((invoice) => (
                <Card 
                  key={invoice.id}
                  className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10 hover:shadow-xl hover:shadow-primary/20 transition-all duration-300 hover:-translate-y-1"
                >
                  <CardHeader className="space-y-1">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-primary/5 rounded-xl flex items-center justify-center">
                          <FileText className="w-6 h-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{invoice.date}</CardTitle>
                          <p className="text-sm text-muted-foreground">#{invoice.invoiceNumber}</p>
                        </div>
                      </div>
                      <Badge 
                        variant={invoice.status === 'paid' ? 'default' : 'secondary'}
                        className={invoice.status === 'paid' ? 'bg-green-500/10 text-green-600 border-green-500/20' : ''}
                      >
                        {invoice.status === 'paid' ? 'Betaald' : 'Open'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Type</span>
                        <span className="font-medium capitalize">{invoice.type}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Periode</span>
                        <span className="font-medium">{invoice.period}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Vervaldatum</span>
                        <span className="font-medium">{invoice.dueDate}</span>
                      </div>
                      {invoice.paidDate && (
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Betaald op</span>
                          <span className="font-medium text-green-600">{invoice.paidDate}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="pt-4 border-t">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Totaalbedrag</p>
                          <p className="text-2xl font-bold text-primary">€{invoice.amount.toFixed(2)}</p>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDownloadInvoice(invoice.id)}
                          className="hover:bg-primary hover:text-primary-foreground"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredInvoices.length === 0 && (
              <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
                <CardContent className="py-12 text-center">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Geen facturen gevonden voor dit filter</p>
                </CardContent>
              </Card>
            )}

            {/* Contract Info */}
            <Card className="backdrop-blur-lg bg-card/80 border border-white/20 shadow-lg shadow-muted/10">
              <CardHeader>
                <CardTitle>Contractgegevens</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="font-medium mb-2">Stroomcontract</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tarief:</span>
                        <span>Variabel</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Prijs:</span>
                        <span>€0.25/kWh</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Looptijd:</span>
                        <span>1 jaar</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Gascontract</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Tarief:</span>
                        <span>Vast</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Prijs:</span>
                        <span>€0.85/m³</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Looptijd:</span>
                        <span>2 jaar</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <ProfileSettings />
          </TabsContent>

          {/* Changes Tab */}
          <TabsContent value="changes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Edit className="w-5 h-5 text-primary" />
                  <span>Wijzigingen Doorgeven</span>
                </CardTitle>
                <p className="text-muted-foreground">
                  Selecteer hieronder wat u wilt wijzigen. We helpen u graag verder.
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  {/* Wachtwoord wijzigen */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-energy-blue/15 to-energy-blue/10 border border-white/20 shadow-lg shadow-energy-blue/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-energy-blue/10 rounded-lg flex items-center justify-center">
                          <Lock className="w-6 h-6 text-energy-blue" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">Wachtwoord wijzigen</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Verander uw inloggegevens voor extra beveiliging
                          </p>
                          <Button variant="outline" size="sm">
                            Wijzigen
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Voorschotbedrag wijzigen */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-energy-orange/15 to-energy-orange/10 border border-white/20 shadow-lg shadow-energy-orange/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-energy-orange/10 rounded-lg flex items-center justify-center">
                          <Euro className="w-6 h-6 text-energy-orange" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">Voorschotbedrag wijzigen</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Pas uw maandelijkse voorschot aan
                          </p>
                          <Button variant="outline" size="sm">
                            Aanpassen
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Bankgegevens wijzigen */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-energy-green/15 to-energy-green/10 border border-white/20 shadow-lg shadow-energy-green/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-energy-green/10 rounded-lg flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-energy-green" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">Bankgegevens wijzigen</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Update uw betaalgegevens en IBAN
                          </p>
                          <Button variant="outline" size="sm">
                            Bewerken
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Verhuizing doorgeven */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-purple-500/15 to-purple-500/10 border border-white/20 shadow-lg shadow-purple-500/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center">
                          <MapPin className="w-6 h-6 text-purple-500" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">Verhuizing doorgeven</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Meld uw nieuwe adres en regelen wij alles
                          </p>
                          <Button variant="outline" size="sm">
                            Melden
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* E-mailadres wijzigen */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-teal-500/15 to-teal-500/10 border border-white/20 shadow-lg shadow-teal-500/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-teal-500/10 rounded-lg flex items-center justify-center">
                          <Mail className="w-6 h-6 text-teal-500" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">E-mailadres(sen) wijzigen</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Update uw contactgegevens
                          </p>
                          <Button variant="outline" size="sm">
                            Wijzigen
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Persoonlijke gegevens aanpassen */}
                  <Card className="relative overflow-hidden hover:shadow-md transition-shadow cursor-pointer backdrop-blur-lg bg-gradient-to-br from-indigo-500/15 to-indigo-500/10 border border-white/20 shadow-lg shadow-indigo-500/10">
                    
                    <CardContent className="relative p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-indigo-500/10 rounded-lg flex items-center justify-center">
                          <UserCog className="w-6 h-6 text-indigo-500" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold mb-2">Persoonlijke gegevens aanpassen</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            Wijzig uw naam, telefoonnummer of andere gegevens
                          </p>
                          <Button variant="outline" size="sm">
                            Bewerken
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            {/* Additional Information Card */}
            <Card>
              <CardHeader>
                <CardTitle>Belangrijke informatie</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium mb-2 flex items-center space-x-2">
                      <Settings className="w-4 h-4" />
                      <span>Verwerkingstijd</span>
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      De meeste wijzigingen worden binnen 1-2 werkdagen verwerkt. 
                      Voor spoedeisende wijzigingen kunt u contact opnemen met onze klantenservice.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <h4 className="font-medium mb-2 flex items-center space-x-2">
                      <HelpCircle className="w-4 h-4" />
                      <span>Hulp nodig?</span>
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Heeft u vragen over een wijziging? Neem contact op via telefoon, e-mail of live chat.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* FAQ Tab */}
          <TabsContent value="faq" className="space-y-6">
            <FAQ onOpenChatBot={() => window.dispatchEvent(new Event('open-sparky'))} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default EnergyDashboard;