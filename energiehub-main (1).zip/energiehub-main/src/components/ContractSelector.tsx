import { Building2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useContracts } from "@/hooks/useContracts";

interface ContractSelectorProps {
  selectedContractId: string | null;
  onSelectContract: (contractId: string) => void;
}

const ContractSelector = ({ selectedContractId, onSelectContract }: ContractSelectorProps) => {
  const { data: contracts, isLoading } = useContracts();

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 px-4 py-2 bg-card/80 backdrop-blur-lg border border-white/20 rounded-lg">
        <Building2 className="w-4 h-4 text-primary" />
        <span className="text-sm text-muted-foreground">Laden...</span>
      </div>
    );
  }

  if (!contracts || contracts.length === 0) {
    return null;
  }

  const selectedContract = contracts.find(c => c.id === selectedContractId) || contracts[0];

  // If no contract is selected yet, select the first one
  if (!selectedContractId && contracts.length > 0 && selectedContract) {
    onSelectContract(selectedContract.id);
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          className="flex items-center gap-3 px-4 py-2 h-auto bg-card/80 backdrop-blur-lg border border-white/20 hover:bg-card/90"
        >
          <Building2 className="w-4 h-4 text-primary" />
          <div className="flex flex-col items-start">
            <span className="text-sm font-medium">
              {selectedContract?.contract_number || "Selecteer aansluiting"}
            </span>
            {selectedContract && (
              <span className="text-xs text-muted-foreground">
                {selectedContract.labels?.name || selectedContract.contract_type}
              </span>
            )}
          </div>
          {contracts.length > 1 && (
            <ChevronDown className="w-4 h-4 text-muted-foreground ml-2" />
          )}
        </Button>
      </DropdownMenuTrigger>
      {contracts.length > 1 && (
        <DropdownMenuContent align="start" className="w-64 bg-popover/95 backdrop-blur-lg border-white/20 z-50">
          {contracts.map((contract) => (
            <DropdownMenuItem
              key={contract.id}
              onClick={() => onSelectContract(contract.id)}
              className="flex flex-col items-start gap-1 cursor-pointer hover:bg-muted/50"
            >
              <div className="flex items-center justify-between w-full">
                <span className="font-medium">{contract.contract_number}</span>
                {contract.id === selectedContractId && (
                  <Badge variant="secondary" className="text-xs">Actief</Badge>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{contract.labels?.name || contract.contract_type}</span>
                <span>•</span>
                <span className="capitalize">{contract.tariff_type}</span>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      )}
    </DropdownMenu>
  );
};

export default ContractSelector;
