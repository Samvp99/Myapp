import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Mail, Phone, MapPin } from "lucide-react";

interface ProfileData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
  iban: string;
}

const ProfileSettings = () => {
  const profileData: ProfileData = {
    firstName: "Jan",
    lastName: "de Vries", 
    email: "jan.devries@email.com",
    phone: "06-12345678",
    address: "Hoofdstraat 123",
    city: "Amsterdam",
    postalCode: "1234 AB",
    iban: "NL91 ABNA 0417 1643 00",
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold">Persoonlijke Gegevens</h2>
        <p className="text-sm text-muted-foreground">Je accountinformatie en contactgegevens</p>
      </div>

      <div className="space-y-4 sm:space-y-6">
          {/* Persoonlijke Informatie */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5 text-primary" />
                <span>Persoonlijke Informatie</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Voornaam</Label>
                  <Input value={profileData.firstName} disabled />
                </div>
                <div className="space-y-2">
                  <Label>Achternaam</Label>
                  <Input value={profileData.lastName} disabled />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Informatie */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="w-5 h-5 text-primary" />
                <span>Contact Informatie</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>E-mailadres</Label>
                <Input value={profileData.email} type="email" disabled />
              </div>
              <div className="space-y-2">
                <Label>Telefoonnummer</Label>
                <Input value={profileData.phone} disabled />
              </div>
            </CardContent>
          </Card>

          {/* Adres Informatie */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-primary" />
                <span>Adresgegevens</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Straat en huisnummer</Label>
                <Input value={profileData.address} disabled />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Postcode</Label>
                  <Input value={profileData.postalCode} disabled />
                </div>
                <div className="space-y-2">
                  <Label>Plaats</Label>
                  <Input value={profileData.city} disabled />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Betaalgegevens */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Phone className="w-5 h-5 text-primary" />
                <span>Betaalgegevens</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Label>IBAN nummer</Label>
                <Input value={profileData.iban} disabled />
              </div>
            </CardContent>
          </Card>

      </div>
    </div>
  );
};

export default ProfileSettings;