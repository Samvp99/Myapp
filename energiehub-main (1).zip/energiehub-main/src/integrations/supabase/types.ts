export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      contracts: {
        Row: {
          contract_number: string
          contract_type: string
          created_at: string
          end_date: string | null
          id: string
          label_id: string | null
          start_date: string
          status: string
          tariff_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          contract_number: string
          contract_type: string
          created_at?: string
          end_date?: string | null
          id?: string
          label_id?: string | null
          start_date: string
          status?: string
          tariff_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          contract_number?: string
          contract_type?: string
          created_at?: string
          end_date?: string | null
          id?: string
          label_id?: string | null
          start_date?: string
          status?: string
          tariff_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "labels"
            referencedColumns: ["id"]
          },
        ]
      }
      energy_consumption: {
        Row: {
          consumption_period_kwh: number | null
          consumption_period_m3: number | null
          contract_id: string
          created_at: string
          energy_type: string
          id: string
          label_id: string | null
          meter_reading: number
          reading_date: string
          user_id: string
        }
        Insert: {
          consumption_period_kwh?: number | null
          consumption_period_m3?: number | null
          contract_id: string
          created_at?: string
          energy_type: string
          id?: string
          label_id?: string | null
          meter_reading: number
          reading_date: string
          user_id: string
        }
        Update: {
          consumption_period_kwh?: number | null
          consumption_period_m3?: number | null
          contract_id?: string
          created_at?: string
          energy_type?: string
          id?: string
          label_id?: string | null
          meter_reading?: number
          reading_date?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "energy_consumption_contract_id_fkey"
            columns: ["contract_id"]
            isOneToOne: false
            referencedRelation: "contracts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "energy_consumption_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "labels"
            referencedColumns: ["id"]
          },
        ]
      }
      energy_prices: {
        Row: {
          created_at: string
          energy_type: string
          id: string
          price_per_unit: number
          tariff_type: string
          valid_from: string
          valid_until: string | null
        }
        Insert: {
          created_at?: string
          energy_type: string
          id?: string
          price_per_unit: number
          tariff_type: string
          valid_from: string
          valid_until?: string | null
        }
        Update: {
          created_at?: string
          energy_type?: string
          id?: string
          price_per_unit?: number
          tariff_type?: string
          valid_from?: string
          valid_until?: string | null
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount_paid: number | null
          amount_total: number
          contract_id: string
          created_at: string
          due_date: string
          energy_cost: number | null
          id: string
          invoice_date: string
          invoice_number: string
          label_id: string | null
          network_cost: number | null
          period_end: string
          period_start: string
          status: string
          taxes: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_paid?: number | null
          amount_total: number
          contract_id: string
          created_at?: string
          due_date: string
          energy_cost?: number | null
          id?: string
          invoice_date: string
          invoice_number: string
          label_id?: string | null
          network_cost?: number | null
          period_end: string
          period_start: string
          status?: string
          taxes?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_paid?: number | null
          amount_total?: number
          contract_id?: string
          created_at?: string
          due_date?: string
          energy_cost?: number | null
          id?: string
          invoice_date?: string
          invoice_number?: string
          label_id?: string | null
          network_cost?: number | null
          period_end?: string
          period_start?: string
          status?: string
          taxes?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_contract_id_fkey"
            columns: ["contract_id"]
            isOneToOne: false
            referencedRelation: "contracts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "labels"
            referencedColumns: ["id"]
          },
        ]
      }
      labels: {
        Row: {
          accent_color: string
          contact_address: string | null
          contact_email: string | null
          contact_phone: string | null
          created_at: string
          electricity_tariff: number | null
          gas_tariff: number | null
          id: string
          logo_url: string | null
          name: string
          primary_color: string
          secondary_color: string
          slug: string
          updated_at: string
          website_url: string | null
        }
        Insert: {
          accent_color?: string
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          electricity_tariff?: number | null
          gas_tariff?: number | null
          id?: string
          logo_url?: string | null
          name: string
          primary_color?: string
          secondary_color?: string
          slug: string
          updated_at?: string
          website_url?: string | null
        }
        Update: {
          accent_color?: string
          contact_address?: string | null
          contact_email?: string | null
          contact_phone?: string | null
          created_at?: string
          electricity_tariff?: number | null
          gas_tariff?: number | null
          id?: string
          logo_url?: string | null
          name?: string
          primary_color?: string
          secondary_color?: string
          slug?: string
          updated_at?: string
          website_url?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address_city: string | null
          address_country: string | null
          address_number: string | null
          address_postal_code: string | null
          address_street: string | null
          created_at: string
          customer_number: string | null
          email: string | null
          first_name: string | null
          id: string
          label_id: string | null
          last_name: string | null
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address_city?: string | null
          address_country?: string | null
          address_number?: string | null
          address_postal_code?: string | null
          address_street?: string | null
          created_at?: string
          customer_number?: string | null
          email?: string | null
          first_name?: string | null
          id?: string
          label_id?: string | null
          last_name?: string | null
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address_city?: string | null
          address_country?: string | null
          address_number?: string | null
          address_postal_code?: string | null
          address_street?: string | null
          created_at?: string
          customer_number?: string | null
          email?: string | null
          first_name?: string | null
          id?: string
          label_id?: string | null
          last_name?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "labels"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          label_id: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          label_id?: string | null
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          label_id?: string | null
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_label_id_fkey"
            columns: ["label_id"]
            isOneToOne: false
            referencedRelation: "labels"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_label: {
        Args: { _user_id: string }
        Returns: string
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      request_wrapper: {
        Args: { body?: Json; headers?: Json; method?: string; url: string }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin" | "label_manager" | "customer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "label_manager", "customer"],
    },
  },
} as const
