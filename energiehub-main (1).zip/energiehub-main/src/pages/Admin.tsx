import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserRole } from '@/hooks/useUserRole';
import { useLabels } from '@/hooks/useLabels';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, Plus, Settings, Users } from 'lucide-react';
import { LabelForm } from '@/components/admin/LabelForm';
import { LabelsList } from '@/components/admin/LabelsList';
import { Skeleton } from '@/components/ui/skeleton';

const Admin = () => {
  const navigate = useNavigate();
  const { role, isLoading: roleLoading, isAdmin } = useUserRole();
  const { labels, isLoading: labelsLoading } = useLabels();
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedLabelId, setSelectedLabelId] = useState<string | null>(null);

  useEffect(() => {
    if (!roleLoading && !isAdmin) {
      navigate('/');
    }
  }, [role, roleLoading, isAdmin, navigate]);

  if (roleLoading || labelsLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <Skeleton className="h-12 w-64" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Settings className="h-8 w-8" />
                Admin Portaal
              </h1>
              <p className="text-muted-foreground mt-1">
                Beheer al je labels en instellingen
              </p>
            </div>
            <Button onClick={() => navigate('/')}>
              Terug naar Dashboard
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-8">
        <Tabs defaultValue="labels" className="space-y-6">
          <TabsList>
            <TabsTrigger value="labels" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              Labels
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Gebruikers
            </TabsTrigger>
          </TabsList>

          <TabsContent value="labels" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Label Management</CardTitle>
                    <CardDescription>
                      Beheer je white-label configuraties
                    </CardDescription>
                  </div>
                  <Button 
                    onClick={() => setShowCreateForm(true)}
                    className="flex items-center gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    Nieuw Label
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {showCreateForm ? (
                  <LabelForm 
                    onSuccess={() => setShowCreateForm(false)}
                    onCancel={() => setShowCreateForm(false)}
                  />
                ) : selectedLabelId ? (
                  <LabelForm 
                    labelId={selectedLabelId}
                    onSuccess={() => setSelectedLabelId(null)}
                    onCancel={() => setSelectedLabelId(null)}
                  />
                ) : (
                  <LabelsList 
                    labels={labels || []}
                    onEdit={(id) => setSelectedLabelId(id)}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>Gebruikers Management</CardTitle>
                <CardDescription>
                  Beheer gebruikers en hun rollen (binnenkort beschikbaar)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Deze functionaliteit wordt binnenkort toegevoegd.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
