import EnergyDashboard from "@/components/EnergyDashboard";

const Index = () => {
  return <EnergyDashboard />;
};

export default Index;
