import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/components/ui/sonner";
import { supabase } from "@/integrations/supabase/client";

const Auth = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");

  const [showBolts, setShowBolts] = useState(false);
  const triggerLightning = () => {
    setShowBolts(false);
    setTimeout(() => setShowBolts(true), 0);
    setTimeout(() => setShowBolts(false), 1200);
  };

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        // After login/signup, ensure a profile exists
        setTimeout(() => {
          ensureProfile(session.user.id, session.user.email ?? null);
        }, 0);
        navigate("/", { replace: true });
      }
    });
    return () => subscription.unsubscribe();
  }, [navigate]);

  const ensureProfile = async (userId: string, email: string | null) => {
    try {
      const { data: existing } = await supabase
        .from("profiles")
        .select("id")
        .eq("user_id", userId)
        .maybeSingle();

      if (!existing) {
        await supabase.from("profiles").insert({ user_id: userId, email: email ?? undefined });
      }
    } catch (err) {
      console.error("ensureProfile error", err);
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast("Ingelogd", { description: "Je bent succesvol ingelogd." });
    } catch (err: any) {
      toast("Fout bij inloggen", { description: err.message, className: "text-destructive" });
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const redirectUrl = `${window.location.origin}/`;
      const { error } = await supabase.auth.signUp({
        email: regEmail,
        password: regPassword,
        options: { emailRedirectTo: redirectUrl },
      });
      if (error) throw error;
      toast("Check je e-mail", { description: "Bevestig je e-mailadres om in te loggen." });
    } catch (err: any) {
      toast("Fout bij registreren", { description: err.message, className: "text-destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-card/90 backdrop-blur-lg border border-white/20 shadow-xl animate-enter">
        <CardHeader>
          <CardTitle className="text-center">Aanmelden of Registreren</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Inloggen</TabsTrigger>
              <TabsTrigger value="register">Registreren</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="pt-4">
              <form onSubmit={handleSignIn} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Wachtwoord</Label>
                  <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Button type="submit" disabled={loading} onClick={triggerLightning} className="w-full">Inloggen</Button>
                    {showBolts && (
                      <div className="pointer-events-none absolute inset-0 overflow-visible">
                        <span className="absolute -top-2 -left-2 select-none" style={{ animation: "bolt-pop-tl 1.1s ease-out forwards", animationDelay: "0ms" }}>⚡</span>
                        <span className="absolute -top-2 -right-2 select-none" style={{ animation: "bolt-pop-tr 1.1s ease-out forwards", animationDelay: "50ms" }}>⚡</span>
                        <span className="absolute -bottom-2 -left-2 select-none" style={{ animation: "bolt-pop-bl 1.1s ease-out forwards", animationDelay: "100ms" }}>⚡</span>
                        <span className="absolute -bottom-2 -right-2 select-none" style={{ animation: "bolt-pop-br 1.1s ease-out forwards", animationDelay: "150ms" }}>⚡</span>
                        <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 select-none" style={{ animation: "bolt-pop-center 1.1s ease-out forwards", animationDelay: "75ms" }}>⚡</span>
                      </div>
                    )}
                  </div>
                  <Button type="button" variant="secondary" onClick={() => navigate("/")} className="hover-scale">Terug</Button>
                </div>
              </form>
            </TabsContent>

            <TabsContent value="register" className="pt-4">
              <form onSubmit={handleSignUp} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="reg-email">E-mail</Label>
                  <Input id="reg-email" type="email" value={regEmail} onChange={(e) => setRegEmail(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-password">Wachtwoord</Label>
                  <Input id="reg-password" type="password" value={regPassword} onChange={(e) => setRegPassword(e.target.value)} required />
                </div>
                <div className="flex items-center gap-2">
                  <Button type="submit" disabled={loading} className="flex-1">Registreren</Button>
                  <Button type="button" variant="secondary" onClick={() => navigate("/")} className="hover-scale">Terug</Button>
                </div>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      <style>{`
        @keyframes bolt-pop-tl { 0% { transform: translate(8px, 8px) scale(0.8); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(-24px, -24px) scale(1.1); opacity: 0; } }
        @keyframes bolt-pop-tr { 0% { transform: translate(-8px, 8px) scale(0.8); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(24px, -24px) scale(1.1); opacity: 0; } }
        @keyframes bolt-pop-bl { 0% { transform: translate(8px, -8px) scale(0.8); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(-24px, 24px) scale(1.1); opacity: 0; } }
        @keyframes bolt-pop-br { 0% { transform: translate(-8px, -8px) scale(0.8); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(24px, 24px) scale(1.1); opacity: 0; } }
        @keyframes bolt-pop-center { 0% { transform: translate(-50%, -50%) scale(0.8); opacity: 0; } 30% { opacity: 1; } 100% { transform: translate(-50%, -50%) scale(1.2); opacity: 0; } }
      `}</style>
    </main>
  );
};

export default Auth;
