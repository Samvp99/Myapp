import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface EnergyPrice {
  price: number;
  timestamp: string;
  unit: string;
}

interface EnergyPriceData {
  timestamp: string;
  electricity: {
    current: EnergyPrice | null;
    previous: EnergyPrice | null;
  };
  gas: {
    current: EnergyPrice | null;
    previous: EnergyPrice | null;
  };
  historical: {
    electricity: Array<{ price: number; timestamp: string }>;
    gas: Array<{ price: number; timestamp: string }>;
  };
}

export const useEnergyPrices = () => {
  const [data, setData] = useState<EnergyPriceData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const fetchPrices = async () => {
    try {
      setError(null);
      const { data: response, error: supabaseError } = await supabase.functions.invoke('energy-prices');
      
      if (supabaseError) {
        throw new Error(supabaseError.message);
      }

      if (response?.error) {
        throw new Error(response.message || 'Failed to fetch energy prices');
      }

      setData(response);
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Error fetching energy prices:', err);
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchPrices();
  }, []);

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(fetchPrices, 30000);
    return () => clearInterval(interval);
  }, []);

  return {
    data,
    loading,
    error,
    lastUpdated,
    refetch: fetchPrices
  };
};