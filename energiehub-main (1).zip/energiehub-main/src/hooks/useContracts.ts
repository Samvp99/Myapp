import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const useContracts = () => {
  return useQuery({
    queryKey: ["contracts"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error("User not authenticated");
      }

      const { data, error } = await supabase
        .from("contracts")
        .select(`
          id,
          contract_number,
          contract_type,
          status,
          tariff_type,
          start_date,
          end_date,
          label_id,
          labels (
            name
          )
        `)
        .eq("user_id", user.id)
        .eq("status", "active")
        .order("start_date", { ascending: false });

      if (error) throw error;
      
      return data || [];
    },
  });
};
