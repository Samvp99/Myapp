import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Label {
  id: string;
  name: string;
  slug: string;
  logo_url: string | null;
  primary_color: string;
  secondary_color: string;
  accent_color: string;
  contact_email: string | null;
  contact_phone: string | null;
  contact_address: string | null;
  website_url: string | null;
  electricity_tariff: number | null;
  gas_tariff: number | null;
  created_at: string;
  updated_at: string;
}

export const useLabels = () => {
  const queryClient = useQueryClient();

  const { data: labels, isLoading } = useQuery({
    queryKey: ['labels'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('labels')
        .select('*')
        .order('name');

      if (error) throw error;
      return data as Label[];
    },
  });

  const createLabel = useMutation({
    mutationFn: async (label: Omit<Label, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('labels')
        .insert(label)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['labels'] });
      toast.success('Label succesvol aangemaakt');
    },
    onError: (error) => {
      toast.error('Fout bij aanmaken label: ' + error.message);
    },
  });

  const updateLabel = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Label> & { id: string }) => {
      const { data, error } = await supabase
        .from('labels')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['labels'] });
      toast.success('Label succesvol bijgewerkt');
    },
    onError: (error) => {
      toast.error('Fout bij bijwerken label: ' + error.message);
    },
  });

  return {
    labels,
    isLoading,
    createLabel: createLabel.mutate,
    updateLabel: updateLabel.mutate,
  };
};
