import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';

interface SmartMeterReading {
  timestamp: string;
  electricity: {
    power_consumed: number; // kW
    power_produced: number; // kW (zonnepanelen)
    energy_consumed_low: number; // kWh (dal tarief)
    energy_consumed_high: number; // kWh (piek tarief)
    energy_produced_low: number; // kWh
    energy_produced_high: number; // kWh
  };
  gas: {
    volume: number; // m³
  };
}

interface SmartMeterStatus {
  connected: boolean;
  lastReading: Date | null;
  meterType: string;
  signalStrength: number;
}

interface UsageThresholds {
  electricity: {
    high: number; // kW
    critical: number; // kW
  };
  gas: {
    daily: number; // m³ per dag
  };
  weekly: {
    limit: number; // kWh per week
    warning: number; // kWh waarschuwingsdrempel
  };
}

export const useSmartMeterData = (connected: boolean = false, contractId: string | null = null) => {
  const [currentReading, setCurrentReading] = useState<SmartMeterReading | null>(null);
  const [status, setStatus] = useState<SmartMeterStatus>({
    connected,
    lastReading: null,
    meterType: 'ISKRA AM550-ED',
    signalStrength: 85
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastWarningTime, setLastWarningTime] = useState<Date | null>(null);
  const [weeklyUsage, setWeeklyUsage] = useState(0); // kWh deze week
  const [weeklyWarningShown, setWeeklyWarningShown] = useState(false);
  const { toast } = useToast();

  // Verbruiksdrempels
  const thresholds: UsageThresholds = {
    electricity: {
      high: 4.0, // 4kW - gemiddeld hoog verbruik
      critical: 6.0, // 6kW - zeer hoog verbruik
    },
    gas: {
      daily: 8.0, // 8m³ per dag - hoog gasverbruik
    },
    weekly: {
      limit: 500, // 500 kWh per week limiet
      warning: 400, // waarschuwing bij 400 kWh (80% van limiet)
    },
  };

  // Simuleer wekelijks verbruik (realistische waarden)
  const updateWeeklyUsage = () => {
    const now = new Date();
    const dayOfWeek = now.getDay(); // 0 = zondag, 1 = maandag, etc.
    const hourOfDay = now.getHours();
    
    // Simuleer cumulatief wekelijks verbruik
    // Basis: ~70 kWh per dag, varieert per dag van de week
    const dailyBase = [65, 75, 72, 68, 71, 80, 85]; // zondag tot zaterdag
    let estimatedWeeklyUsage = 0;
    
    // Tel verbruik van vorige dagen deze week op
    for (let i = 1; i <= dayOfWeek; i++) {
      estimatedWeeklyUsage += dailyBase[i] + (Math.random() - 0.5) * 10;
    }
    
    // Voeg verbruik van vandaag toe (gebaseerd op uur van de dag)
    const todayProgress = hourOfDay / 24;
    estimatedWeeklyUsage += (dailyBase[dayOfWeek] * todayProgress) + (Math.random() - 0.5) * 5;
    
    setWeeklyUsage(Math.max(0, estimatedWeeklyUsage));
  };

  // Controleer wekelijkse verbruiksgrens
  const checkWeeklyUsageWarning = () => {
    if (weeklyWarningShown) return;
    
    if (weeklyUsage >= thresholds.weekly.warning && weeklyUsage < thresholds.weekly.limit) {
      toast({
        title: "📊 Wekelijks verbruik waarschuwing",
        description: `U heeft al ${weeklyUsage.toFixed(0)} kWh gebruikt van uw ${thresholds.weekly.limit} kWh weekbudget. Let op uw verbruik!`,
        variant: "default",
      });
      setWeeklyWarningShown(true);
    } else if (weeklyUsage >= thresholds.weekly.limit) {
      toast({
        title: "⚠️ Weekbudget overschreden!",
        description: `U heeft ${weeklyUsage.toFixed(0)} kWh gebruikt. Uw weekbudget van ${thresholds.weekly.limit} kWh is overschreden.`,
        variant: "destructive",
      });
      setWeeklyWarningShown(true);
    }
  };

  // Reset wekelijkse waarschuwing elke maandag
  useEffect(() => {
    const now = new Date();
    if (now.getDay() === 1 && now.getHours() === 0) { // Maandag 00:00
      setWeeklyWarningShown(false);
    }
  }, []);

  // Controleer verbruiksniveaus en toon waarschuwingen
  const checkUsageWarnings = (reading: SmartMeterReading) => {
    const now = new Date();
    const netPower = reading.electricity.power_consumed - reading.electricity.power_produced;
    
    // Voorkom spam - slechts één waarschuwing per 5 minuten
    if (lastWarningTime && (now.getTime() - lastWarningTime.getTime()) < 300000) {
      return;
    }

    if (netPower >= thresholds.electricity.critical) {
      toast({
        title: "⚠️ Kritiek hoog verbruik!",
        description: `Uw elektriciteitsverbruik is ${netPower.toFixed(1)}kW. Dit is zeer hoog en kan leiden tot hoge kosten.`,
        variant: "destructive",
      });
      setLastWarningTime(now);
    } else if (netPower >= thresholds.electricity.high) {
      toast({
        title: "🔥 Hoog verbruik gedetecteerd",
        description: `Uw elektriciteitsverbruik is ${netPower.toFixed(1)}kW. Overweeg apparaten uit te schakelen om kosten te besparen.`,
        variant: "default",
      });
      setLastWarningTime(now);
    }
  };
  const generateReading = (): SmartMeterReading => {
    const now = new Date();
    const hour = now.getHours();
    
    // Simuleer dagelijks verbruikspatroon
    let basePower = 0.3; // Standby verbruik
    
    if (hour >= 6 && hour <= 8) basePower = 2.5; // Ochtendspits
    else if (hour >= 9 && hour <= 17) basePower = 1.2; // Overdag
    else if (hour >= 18 && hour <= 21) basePower = 3.8; // Avondspits
    else if (hour >= 22 || hour <= 5) basePower = 0.8; // Nacht
    
    // Voeg wat randomness toe voor realisme
    const variation = (Math.random() - 0.5) * 0.8;
    const currentPower = Math.max(0.1, basePower + variation);
    
    // Simuleer zonnepanelen productie (alleen overdag)
    const solarProduction = hour >= 7 && hour <= 19 
      ? Math.max(0, 2.2 * Math.sin((hour - 7) * Math.PI / 12) + (Math.random() - 0.5) * 0.5)
      : 0;

    return {
      timestamp: now.toISOString(),
      electricity: {
        power_consumed: Math.round(currentPower * 1000) / 1000,
        power_produced: Math.round(solarProduction * 1000) / 1000,
        energy_consumed_low: 1247.583, // Cumulatief dal
        energy_consumed_high: 1052.194, // Cumulatief piek
        energy_produced_low: 234.567,
        energy_produced_high: 189.123,
      },
      gas: {
        volume: 847.392 // Cumulatief gas m³
      }
    };
  };

  // Simuleer live data updates
  useEffect(() => {
    if (!status.connected || !contractId) {
      setCurrentReading(null);
      return;
    }

    setLoading(true);
    setError(null);

    // Initiële reading en wekelijks verbruik
    const initialReading = generateReading();
    setCurrentReading(initialReading);
    setStatus(prev => ({ ...prev, lastReading: new Date() }));
    updateWeeklyUsage();
    setLoading(false);

    // Update elke 10 seconden voor realtime gevoel
    const interval = setInterval(() => {
      try {
        const newReading = generateReading();
        setCurrentReading(newReading);
        setStatus(prev => ({ ...prev, lastReading: new Date() }));
        
        // Update wekelijks verbruik
        updateWeeklyUsage();
        
        // Controleer waarschuwingen
        checkUsageWarnings(newReading);
        checkWeeklyUsageWarning();
      } catch (err) {
        console.error('Error generating smart meter reading:', err);
        setError('Verbindingsfout met slimme meter');
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [status.connected, contractId]);

  const connectMeter = () => {
    setStatus(prev => ({ ...prev, connected: true }));
  };

  const disconnectMeter = () => {
    setStatus(prev => ({ ...prev, connected: false }));
    setCurrentReading(null);
  };

  return {
    currentReading,
    status,
    loading,
    error,
    weeklyUsage,
    weeklyLimit: thresholds.weekly.limit,
    connectMeter,
    disconnectMeter
  };
};