-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'label_manager', 'customer');

-- Create labels table for white-label configuration
CREATE TABLE public.labels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  logo_url TEXT,
  primary_color TEXT NOT NULL DEFAULT 'hsl(142, 76%, 36%)',
  secondary_color TEXT NOT NULL DEFAULT 'hsl(142, 76%, 45%)',
  accent_color TEXT NOT NULL DEFAULT 'hsl(142, 76%, 30%)',
  contact_email TEXT,
  contact_phone TEXT,
  contact_address TEXT,
  website_url TEXT,
  electricity_tariff NUMERIC(10,5),
  gas_tariff NUMERIC(10,5),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role public.app_role NOT NULL,
  label_id UUID REFERENCES public.labels(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, role, label_id)
);

-- Add label_id to existing tables
ALTER TABLE public.profiles ADD COLUMN label_id UUID REFERENCES public.labels(id) ON DELETE CASCADE;
ALTER TABLE public.contracts ADD COLUMN label_id UUID REFERENCES public.labels(id) ON DELETE CASCADE;
ALTER TABLE public.invoices ADD COLUMN label_id UUID REFERENCES public.labels(id) ON DELETE CASCADE;
ALTER TABLE public.energy_consumption ADD COLUMN label_id UUID REFERENCES public.labels(id) ON DELETE CASCADE;

-- Enable RLS on new tables
ALTER TABLE public.labels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check user role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Create security definer function to get user's label
CREATE OR REPLACE FUNCTION public.get_user_label(_user_id UUID)
RETURNS UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT label_id
  FROM public.profiles
  WHERE user_id = _user_id
  LIMIT 1
$$;

-- RLS Policies for labels table
CREATE POLICY "Admins can view all labels"
  ON public.labels FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Label managers can view their label"
  ON public.labels FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'label_manager') 
    AND id IN (
      SELECT label_id FROM public.user_roles 
      WHERE user_id = auth.uid() AND role = 'label_manager'
    )
  );

CREATE POLICY "Admins can insert labels"
  ON public.labels FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all labels"
  ON public.labels FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Label managers can update their label"
  ON public.labels FOR UPDATE
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'label_manager')
    AND id IN (
      SELECT label_id FROM public.user_roles 
      WHERE user_id = auth.uid() AND role = 'label_manager'
    )
  );

-- RLS Policies for user_roles table
CREATE POLICY "Admins can view all user roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Label managers can view their label's roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'label_manager')
    AND label_id IN (
      SELECT label_id FROM public.user_roles 
      WHERE user_id = auth.uid() AND role = 'label_manager'
    )
  );

CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can insert user roles"
  ON public.user_roles FOR INSERT
  TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Update existing RLS policies for multi-tenant isolation

-- Profiles: Users see only their own profile, admins see all, label managers see their label
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid() 
    OR public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'label_manager')
      AND label_id IN (
        SELECT label_id FROM public.user_roles 
        WHERE user_id = auth.uid() AND role = 'label_manager'
      )
    )
  );

DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid());

-- Contracts: Label isolation
DROP POLICY IF EXISTS "Users can view their own contracts" ON public.contracts;
CREATE POLICY "Users can view their own contracts"
  ON public.contracts FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'label_manager')
      AND label_id IN (
        SELECT label_id FROM public.user_roles 
        WHERE user_id = auth.uid() AND role = 'label_manager'
      )
    )
  );

-- Invoices: Label isolation
DROP POLICY IF EXISTS "Users can view their own invoices" ON public.invoices;
CREATE POLICY "Users can view their own invoices"
  ON public.invoices FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'label_manager')
      AND label_id IN (
        SELECT label_id FROM public.user_roles 
        WHERE user_id = auth.uid() AND role = 'label_manager'
      )
    )
  );

-- Energy consumption: Label isolation
DROP POLICY IF EXISTS "Users can view their own consumption" ON public.energy_consumption;
CREATE POLICY "Users can view their own consumption"
  ON public.energy_consumption FOR SELECT
  TO authenticated
  USING (
    user_id = auth.uid()
    OR public.has_role(auth.uid(), 'admin')
    OR (
      public.has_role(auth.uid(), 'label_manager')
      AND label_id IN (
        SELECT label_id FROM public.user_roles 
        WHERE user_id = auth.uid() AND role = 'label_manager'
      )
    )
  );

-- Create trigger for labels updated_at
CREATE TRIGGER update_labels_updated_at
  BEFORE UPDATE ON public.labels
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Update handle_new_user function to support label assignment
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, first_name, last_name)
  VALUES (
    NEW.id, 
    NEW.email,
    NEW.raw_user_meta_data ->> 'first_name',
    NEW.raw_user_meta_data ->> 'last_name'
  );
  
  -- Assign customer role by default
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'customer');
  
  RETURN NEW;
END;
$$;