import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NEDResponse {
  data: Array<{
    datetime: string;
    value: number;
  }>;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const now = new Date();
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const formatDate = (date: Date) => date.toISOString().split('T')[0];
    
    // Fetch electricity prices (hourly day-ahead prices)
    const electricityUrl = `https://ned.nl/api/v1/utilisation/?type_id=70&date_from=${formatDate(yesterday)}&date_to=${formatDate(now)}&granularity=PT1H`;
    
    // Fetch gas prices (TTF day-ahead prices)
    const gasUrl = `https://ned.nl/api/v1/utilisation/?type_id=111&date_from=${formatDate(yesterday)}&date_to=${formatDate(now)}&granularity=P1D`;

    console.log('Fetching electricity prices from:', electricityUrl);
    console.log('Fetching gas prices from:', gasUrl);

    const [electricityResponse, gasResponse] = await Promise.all([
      fetch(electricityUrl),
      fetch(gasUrl)
    ]);

    if (!electricityResponse.ok) {
      console.error('Electricity API error:', electricityResponse.status, await electricityResponse.text());
    }
    
    if (!gasResponse.ok) {
      console.error('Gas API error:', gasResponse.status, await gasResponse.text());
    }

    const electricityData: NEDResponse = electricityResponse.ok ? await electricityResponse.json() : { data: [] };
    const gasData: NEDResponse = gasResponse.ok ? await gasResponse.json() : { data: [] };

    // Get latest prices
    const latestElectricity = electricityData.data?.[electricityData.data.length - 1] || null;
    const latestGas = gasData.data?.[gasData.data.length - 1] || null;

    // Get previous prices for comparison
    const previousElectricity = electricityData.data?.[electricityData.data.length - 2] || null;
    const previousGas = gasData.data?.[gasData.data.length - 2] || null;

    const result = {
      timestamp: new Date().toISOString(),
      electricity: {
        current: latestElectricity ? {
          price: latestElectricity.value / 1000, // Convert from €/MWh to €/kWh
          timestamp: latestElectricity.datetime,
          unit: '€/kWh'
        } : null,
        previous: previousElectricity ? {
          price: previousElectricity.value / 1000,
          timestamp: previousElectricity.datetime,
          unit: '€/kWh'
        } : null
      },
      gas: {
        current: latestGas ? {
          price: latestGas.value / 35.17, // Convert from €/MWh to €/m³ (approximation)
          timestamp: latestGas.datetime,
          unit: '€/m³'
        } : null,
        previous: previousGas ? {
          price: previousGas.value / 35.17,
          timestamp: previousGas.datetime,
          unit: '€/m³'
        } : null
      },
      historical: {
        electricity: electricityData.data?.slice(-24).map(item => ({
          price: item.value / 1000,
          timestamp: item.datetime
        })) || [],
        gas: gasData.data?.slice(-7).map(item => ({
          price: item.value / 35.17,
          timestamp: item.datetime
        })) || []
      }
    };

    console.log('Returning energy price data:', result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error fetching energy prices:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch energy prices',
      message: error.message,
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});